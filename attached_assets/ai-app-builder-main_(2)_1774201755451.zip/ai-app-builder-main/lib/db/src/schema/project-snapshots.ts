import { pgTable, text, serial, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { projectsTable } from "./projects";

export const projectSnapshotsTable = pgTable("project_snapshots", {
  id: serial("id").primaryKey(),
  projectId: integer("project_id").notNull().references(() => projectsTable.id, { onDelete: "cascade" }),
  html: text("html").notNull(),
  label: text("label").notNull().default("גרסה"),
  diffStats: jsonb("diff_stats"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type ProjectSnapshot = typeof projectSnapshotsTable.$inferSelect;
