# Adaptive AI Platform — AI App Builder (בונה AI)

## Overview
The Adaptive AI Platform is an AI-powered web and app builder that allows users to generate complete web projects by chatting with Claude. It features an Adaptive AI System with four distinct user modes (Entrepreneur, Builder, Developer, Maker) that dynamically adjust communication style, system prompts, UI, and suggested ideas. The platform includes a Business Memory Layer that persists project DNA across sessions, supporting multi-file projects, a Monaco editor, per-project database/storage, and deployment to services like Netlify/Vercel. Key capabilities include team collaboration, analytics, error and performance monitoring, live cursors, webhooks, and a public gallery for templates. The vision is to provide a versatile and intuitive tool for users of varying technical backgrounds to bring their web projects to life efficiently.

## User Preferences
- **Entrepreneur Mode**: Expects business-oriented language, no technical jargon. Focuses on business advice and discovery questions related to market, audience, and goals.
- **Builder Mode**: Expects tech and product-oriented language, explanations of technical decisions, and alternative suggestions.
- **Developer Mode**: Prefers a peer-to-peer interaction style, focusing on production-grade code, security, and performance notes.
- **Maker Mode**: Prefers a playful interaction style, encouraging experimentation with creative technologies like Three.js, Canvas, WebGL, and WebAudio, and actively discourages monetization or scaling discussions.
- Users can switch modes automatically based on the first message or receive "Grow-With-Me" suggestions for mode upgrades mid-session.
- The AI should extract and save project DNA (business model, target audience, brand colors, creative vibe) after every AI response, and inject this DNA into future system prompts to maintain context.
- The AI should use `claude-haiku-4-5-20251001` for prompt enhancement and DNA extraction due to its speed and cost-efficiency.
- For heavy generation tasks, especially for the SaaS Generator, `claude-sonnet-4-5-20251001` should be used.
- All system prompts should adhere to shared output rules, including HTML output format, preservation rules, and premium design requirements.
- Planning and specification phases are disabled by default (`usePlanningPhase=false`, `useSpecGeneration=false`).

## System Architecture

### Monorepo Structure
The project is organized as a monorepo:
- `artifacts/api-server`: Express 5 + WebSocket API server.
- `artifacts/app-builder`: React + Vite frontend application.
- `lib/db`: Drizzle ORM with PostgreSQL schemas.
- `lib/api-zod`: Zod validators generated from OpenAPI spec.
- `lib/integrations-anthropic-ai`: Anthropic SDK wrapper.

### Core Technical Decisions
- **Authentication**: Cookie-based OIDC via Replit Auth.
- **Encryption**: AES-256-GCM for project secrets.
- **AI Models**: `claude-sonnet-4-5` for core generation, `claude-haiku-4-5-20251001` for prompt enhancement, DNA extraction, and advanced AI tasks (Planner, Deploy Brain, QA, Cost Optimization).
- **Streaming**: Server-Sent Events (SSE) with typed events (text, code, done, error).
- **Real-time**: WebSocket for collaborative presence (cursors, viewers).
- **Database**: PostgreSQL managed by Drizzle ORM, with isolated schemas per project for databases.
- **AI System Prompts**: Dynamically selected based on user mode, integrations, project type, and stack, incorporating both `user_dna` and `project_dna` for contextual relevance.
- **UI/UX**: Dark theme with cyan accents, Rubik font for Hebrew (RTL), Plus Jakarta Sans/Inter for generated content. Maker mode features a distinct purple theme.
- **Multi-file Support**: Projects can be built with React/Next.js, Vue 3, Svelte, or Django stacks, using a specific multi-file manifest extraction format.
- **Live Preview**: esbuild for live bundling of React/JSX projects.
- **Monitoring**: Integrated error monitoring (`app_errors` table, `ErrorsPanel.tsx`) and performance monitoring via Google PageSpeed Insights (`PerformancePanel.tsx`).
- **Collaboration**: Live cursors via WebSocket, team management with roles, and inline code comments.
- **Security**: Rate limiting, input sanitization, AES-256-GCM encryption for secrets, and HMAC-SHA256 signing for webhooks.
- **Advanced AI Systems**:
    - **Planner Agent**: Generates comprehensive project plans (features, screens, APIs, DB schema).
    - **Deployment Brain**: AI-powered recommendation for deployment strategies.
    - **AI QA System**: Auto-generates tests and suggests fixes.
    - **Cost Engine**: Tracks and optimizes resource costs (CPU, RAM, GPU, storage, bandwidth, AI tokens).
    - **SaaS Generator**: One-click generation of SaaS applications.
    - **Runtime Control Plane**: Manages project runtime environments.

## External Dependencies
- **Anthropic**: `claude-sonnet-4-5` and `claude-haiku-4-5-20251001` for AI capabilities.
- **PostgreSQL**: Primary database, accessed via Drizzle ORM.
- **Replit App Storage (GCS)**: Object storage for project assets.
- **Netlify API**: For project deployment and custom domains.
- **Vercel API**: For project deployment.
- **Google PageSpeed Insights**: For performance monitoring and reporting.
- **GitHub**: For Gist export and project syncing.
- **Unsplash**: For generating images within content.
- **CDN Libraries**: A curated selection of over 50 popular frontend libraries (e.g., Tailwind, Bootstrap, Three.js, Chart.js) are available for injection into generated projects.

## Security Architecture

### Terminal WebSocket (`routes/terminal.ts`)
- Disabled by default in production (`ENABLE_TERMINAL=true` env required)
- `buildSafeEnv()` whitelist — only 19 safe env vars pass to child process (no server secrets)
- `BLOCKED_PATTERNS` array blocks: `rm -rf /`, `dd if=`, fork bombs, `sudo`, `curl|bash`, `mkfs`, etc.
- Hebrew user-facing blocked message + structured `logger.warn` with userId and command snippet

### Rate Limiting (`app.ts`)
- General API: 120 req/min (GET exempt)
- AI chat: 20 req/min per user
- Deployments: 5 req/5min per user
- Proxy (`/api/proxy`): 30 req/min per user
- AI proxy (`/api/ai-proxy`): 15 req/min per user

### Project Authorization
- Central `router.param("id", ...)` in `routes/projects/index.ts` enforces ownership on all project-scoped routes
- Runtime (`routes/runtime.ts`): added `checkProjectOwnership()` helper to GET, stop, restart handlers
- Jobs (`routes/jobs.ts`): added user ownership checks to GET/:id and POST/:id/cancel

### Templates Authorization (`routes/templates.ts`)
- `POST /api/templates` verifies the caller owns the source project before snapshotting it as a template
- `POST /api/templates/:id/use` blocks using private templates belonging to other users (403 Forbidden)

### CORS Policy
- In production: explicit allowlist via `ALLOWED_ORIGINS` env or derived from `REPLIT_DEV_DOMAIN`
- Development: permissive (all origins)

## AI System

### Token Optimization
- `SHARED_LIBRARIES` (~500 tokens) only injected for HTML/CSS stacks — not for React/Vue/Svelte/Django
- Additionally, `SHARED_LIBRARIES` is stripped for `fix`, `edit`, and `inspect` intents — saves ~500 tokens on all code-edit requests
- `getSystemPrompt()` accepts optional `intent` param to conditionally exclude library list
- Multi-agent analysis threshold: `350 chars & 25 words` (raised from 200/15)
- Haiku used for intent detection, planning agents, DNA extraction; Sonnet for final generation

### Memory System
- Fire-and-forget errors now logged with `logger.warn` (DNA extraction, chunk extraction)
- `logger` added to `messages.ts` imports for observability

## Data Integrity

### Agent Run (`routes/projects/agent-run.ts`)
- `isHtmlUsable()` validation before persisting AI output
- Atomic DB transaction: project + project_files + snapshot saved together
- Snapshot only created if HTML passes quality check (min 200 chars, proper HTML structure)
- `broadcastProjectUpdate` only fires if HTML is valid

## Documentation
- `docs/security/final-hardening-report.md` — Phase 4 security hardening report
- `docs/ai/prompt-system.md` — AI prompt registry and selection logic
- `docs/ai/orchestration.md` — Full AI orchestration pipeline documentation
- `docs/ai/memory-cleanup.md` — Memory system cleanup and observability notes
- `docs/ai/token-optimization.md` — Token optimization strategy and savings estimates
- `docs/frontend/workspace-shell-plan.md` — Frontend workspace shell panel inventory
- `docs/frontend/component-map.md` — Full frontend component hierarchy
- `docs/engineering/testing-plan.md` — Testing plan with coverage targets and CI checks