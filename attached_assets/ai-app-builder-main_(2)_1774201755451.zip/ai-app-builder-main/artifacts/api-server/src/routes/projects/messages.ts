import { Router } from "express";
import { randomBytes, createHash } from "node:crypto";
import { logger } from "../../lib/logger";
import { eq, asc, desc, and, gte } from "drizzle-orm";
import {
  db,
  projectsTable,
  projectMessagesTable,
  projectFilesTable,
  projectSnapshotsTable,
  deploymentsTable,
  projectDnaTable,
  userDnaTable,
  promptCacheTable,
  qaTestResultsTable,
  userSubscriptionsTable,
} from "@workspace/db";
import { anthropic } from "@workspace/integrations-anthropic-ai";
import { broadcastProjectUpdate } from "../collab";
import { autoCdnInject } from "../../services/ai/preview";
import { detectUserMode } from "../../services/ai/mode";
import { detectChatIntent, getIntentSystemAddition, detectContextualSuggestions } from "../../services/ai/intent";
import type { ChatIntent, DetectedIntent } from "../../services/ai/intent";
import { getProjectDNA, buildDNAContext, buildUserDNAContext, withRetry, extractAndSaveDNA, extractAndSaveMemoryChunks, scoreMemoryChunks, buildMemoryChunkContext, shouldExtractMemory } from "../../services/memory/project-dna";
import type { MemoryChunk } from "../../services/memory/project-dna";
import { runArchitectureAgent, runUiAgent, runSecurityAgent, runPerformanceAgent, buildAgentContext, calculateSkillScore } from "../../services/ai/agents";
import type { AgentAnalysis } from "../../services/ai/agents";
import { getSystemPrompt } from "../../services/ai/system-prompt";
import { PLANNING_SYSTEM_PROMPT, PRODUCT_SPEC_SYSTEM_PROMPT, LANDING_PAGE_DESIGN_RULES, isMarketingPageRequest } from "../../services/ai/prompts/index";
import { createZip } from "./deploy";
import { syncProjectToGitHub } from "./github-sync";
import { getProjectSecretKeys } from "./helpers";
import { recordAiCall, startTimer } from "../../services/telemetry";
import { PROMPT_VERSION } from "../../services/ai/prompts/index";
import { checkRateLimit } from "../../services/rate-limit";
import { computeChangeSummary } from "../../services/ai/change-summary";
import { invalidateBundleCache } from "./bundle";
import {
  ListProjectMessagesParams,
  SendProjectMessageBody,
  SendProjectMessageParams,
} from "@workspace/api-zod";

const router = Router({ mergeParams: true });

// ── Messages list ────────────────────────────────────────────
router.get("/:id/messages", async (req, res) => {
  const params = ListProjectMessagesParams.parse(req.params);

  const project = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, params.id))
    .then((rows) => rows[0]);

  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const messages = await db
    .select()
    .from(projectMessagesTable)
    .where(eq(projectMessagesTable.projectId, params.id))
    .orderBy(asc(projectMessagesTable.createdAt));

  res.json(messages);
});

// ── AI Message (SSE streaming) ───────────────────────────────
router.post("/:id/messages", async (req, res) => {
  const params = SendProjectMessageParams.parse(req.params);
  // Read agent-flow flags before Zod strips unknown fields
  const agentFlow = Boolean((req.body as Record<string, unknown>).agentFlow);
  const useAutoFix = (req.body as Record<string, unknown>).useAutoFix !== false;
  const body = SendProjectMessageBody.parse(req.body);

  // ── Input sanitization ────────────────────────────────────────────────────
  // Strip null bytes and control characters; enforce max length
  const MAX_MSG_CHARS = 8_000;
  const sanitizedContent = body.content
    .replace(/\x00/g, "") // null bytes
    .replace(/[\x01-\x08\x0B-\x1F]/g, "") // control chars except \t \n
    .trim()
    .slice(0, MAX_MSG_CHARS);
  if (!sanitizedContent) {
    res.status(400).json({ error: "תוכן ההודעה לא יכול להיות ריק" });
    return;
  }
  // Mutate the body content to the sanitized value
  (body as { content: string }).content = sanitizedContent;

  const project = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, params.id))
    .then((rows) => rows[0]);

  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }

  const existingMessages = await db
    .select()
    .from(projectMessagesTable)
    .where(eq(projectMessagesTable.projectId, params.id))
    .orderBy(asc(projectMessagesTable.createdAt));

  const isFirstMessage = existingMessages.length === 0;

  // ── Plan Limits Enforcement ───────────────────────────────────────────────
  const PLAN_LIMITS: Record<string, { maxMessages: number; name: string }> = {
    free: { maxMessages: 50, name: "Free" },
    pro: { maxMessages: 200, name: "Pro" },
    studio: { maxMessages: 2000, name: "Studio" },
  };
  const userPlanId = project.userId
    ? await db
        .select({ planId: userSubscriptionsTable.planId })
        .from(userSubscriptionsTable)
        .where(eq(userSubscriptionsTable.userId, project.userId))
        .then((rows) => rows[0]?.planId ?? "free")
        .catch(() => "free")
    : "free";
  const planConfig = PLAN_LIMITS[userPlanId] ?? PLAN_LIMITS.free;
  const sentMessageCount = existingMessages.filter(
    (m) => m.role === "user",
  ).length;
  if (sentMessageCount >= planConfig.maxMessages) {
    res.status(429).json({
      error: `הגעת למגבלת ${planConfig.maxMessages} הודעות של פלן ${planConfig.name}. שדרג את החשבון כדי להמשיך.`,
      limitReached: true,
      plan: userPlanId,
      limit: planConfig.maxMessages,
    });
    return;
  }
  // ─────────────────────────────────────────────────────────────────────────

  // ── Per-minute rate limiting ──────────────────────────────────────────────
  // Prevents a single user from slamming the AI endpoint, independent of the
  // plan-based total-message cap above.
  if (project.userId) {
    const rl = checkRateLimit(project.userId, userPlanId);
    if (!rl.allowed) {
      res.status(429).json({
        error: `שלחת יותר מדי הודעות דקה. נסה שוב בעוד ${Math.ceil(rl.resetInMs / 1000)} שניות.`,
        retryAfterMs: rl.resetInMs,
      });
      return;
    }
  }
  // ─────────────────────────────────────────────────────────────────────────

  // ── Intent Detection ─────────────────────────────────────────────────────
  const hasExistingCode =
    !isFirstMessage && (!!project.previewHtml || existingMessages.length > 0);
  const detectedIntent = detectChatIntent(body.content, hasExistingCode);

  // ── Planning phase detection ──
  // True when: first message AND user didn't explicitly ask to skip planning
  const SKIP_PLANNING_KEYWORDS = [
    "בנה מיד",
    "בנה ישר",
    "התחל לבנות",
    "just build",
    "build now",
    "build it now",
    "skip planning",
    "skip questions",
    "דלג על שאלות",
    "בלי שאלות",
  ];
  const userWantsSkipPlanning = SKIP_PLANNING_KEYWORDS.some((kw) =>
    body.content.toLowerCase().includes(kw.toLowerCase()),
  );
  // Also skip planning if user message is very detailed (>300 chars with clear specs)
  const isVeryDetailed = body.content.length > 300;

  // ── Planning / spec phases are DISABLED — always build immediately ──
  const usePlanningPhase = false;
  const useSpecGeneration = false;

  // Planning phase is fully disabled — always build immediately
  const isAfterPlanningQA = false;
  const isAfterSpecPhase = false;
  const isPlanningAnswerMessage = false;

  // ── Skill Detection Engine ──
  let currentMode = project.userMode;
  const userMessageCount =
    existingMessages.filter((m) => m.role === "user").length + 1;
  // Re-detect mode only on first message — avoid mid-conversation persona flips
  if (isFirstMessage) {
    const detectedMode = detectUserMode(body.content);
    if (detectedMode !== currentMode) {
      currentMode = detectedMode;
      await db
        .update(projectsTable)
        .set({ userMode: currentMode, updatedAt: new Date() })
        .where(eq(projectsTable.id, params.id));
    }
  }

  // ── Fetch Project DNA + User DNA in parallel ─────────────────────────────
  const [projectDna, userDnaRows] = await Promise.all([
    getProjectDNA(params.id),
    db
      .select()
      .from(userDnaTable)
      .where(eq(userDnaTable.userId, project.userId ?? ""))
      .catch(() => [] as (typeof userDnaTable.$inferSelect)[]),
  ]);
  const dnaContext = buildDNAContext(projectDna, currentMode);
  const [userDna] = userDnaRows;
  const userDnaContext = buildUserDNAContext(userDna ?? null);

  // ── Command 5: Score and inject relevant memory chunks ──────────────────
  const rawChunks = (projectDna?.memoryChunks as MemoryChunk[] | null) ?? [];
  const relevantChunks = scoreMemoryChunks(rawChunks, body.content);
  const memoryChunkContext = buildMemoryChunkContext(relevantChunks);

  // ── Save user message (with attachment info note) ──
  const attachmentNote =
    body.attachments && body.attachments.length > 0
      ? "\n\n" + body.attachments.map((a) => `[📎 ${a.name}]`).join(" ")
      : "";
  await db.insert(projectMessagesTable).values({
    projectId: params.id,
    role: "user",
    content: body.content + attachmentNote,
  });

  // ── Build AI message history ──
  // Previous messages are plain text; only the current message can have rich content blocks
  type ContentBlock =
    | { type: "text"; text: string }
    | {
        type: "image";
        source: { type: "base64"; media_type: string; data: string };
      }
    | {
        type: "document";
        source: { type: "base64"; media_type: string; data: string };
      };

  const buildUserContent = (
    text: string,
    attachments?: typeof body.attachments,
  ): string | ContentBlock[] => {
    if (!attachments || attachments.length === 0) return text;

    const blocks: ContentBlock[] = [{ type: "text", text }];

    for (const att of attachments) {
      const mime = att.type.toLowerCase();
      if (
        mime.startsWith("image/jpeg") ||
        mime.startsWith("image/png") ||
        mime.startsWith("image/gif") ||
        mime.startsWith("image/webp")
      ) {
        blocks.push({
          type: "image",
          source: {
            type: "base64",
            media_type: att.type as
              | "image/jpeg"
              | "image/png"
              | "image/gif"
              | "image/webp",
            data: att.data,
          },
        });
      } else if (mime === "application/pdf") {
        blocks.push({
          type: "document",
          source: {
            type: "base64",
            media_type: "application/pdf",
            data: att.data,
          },
        });
      } else {
        // Text-based file — embed content directly as a text block
        blocks.push({
          type: "text",
          text: `\n\n---\nתוכן הקובץ "${att.name}":\n${att.data}`,
        });
      }
    }

    return blocks;
  };

  // When there's existing code, inject it as context so Claude always knows the current state
  const isReactStackForPrompt =
    project.stack === "react" || project.stack === "nextjs";

  // For React projects, load existing files to inject as context
  const existingProjectFiles =
    isReactStackForPrompt && !isFirstMessage
      ? await db
          .select()
          .from(projectFilesTable)
          .where(eq(projectFilesTable.projectId, params.id))
          .orderBy(asc(projectFilesTable.path))
      : [];

  const buildFinalUserContent = (
    text: string,
    attachments?: typeof body.attachments,
  ): string | ContentBlock[] => {
    let enrichedText = text;

    // When building after spec confirmation, inject the spec as explicit context
    if (isAfterSpecPhase && !project.previewHtml) {
      const specContent = existingMessages[3]?.content ?? "";
      enrichedText = `[PRODUCT SPEC — USE THIS AS BLUEPRINT]
${specContent}
[END PRODUCT SPEC]

USER CONFIRMATION: ${text}

Build the complete app based on the Product Spec above. Follow the design style, pages, features, and target audience exactly as specified.`;
    }

    if (isReactStackForPrompt && existingProjectFiles.length > 0) {
      const filesBlock = existingProjectFiles
        .map(
          (f) =>
            `FILE: ${f.path}\n\`\`\`${f.language === "typescript" ? "tsx" : f.language}\n${f.content}\n\`\`\``,
        )
        .join("\n\n");

      enrichedText = `[CURRENT PROJECT FILES — START]
These are the current React files. ONLY output files that need to change.

${filesBlock}
[CURRENT PROJECT FILES — END]

USER REQUEST: ${text}`;
    } else if (!isFirstMessage && project.previewHtml) {
      const isPatchIntent =
        detectedIntent.intent === "fix" || detectedIntent.intent === "edit";
      // For large HTML files in patch mode: inject a truncated version.
      // The full file is ~30-100KB — too much context for a small edit.
      // We keep the first 15KB (structure, styles, scripts header) and last 3KB (closing tags).
      const MAX_PATCH_HTML_CHARS = 18_000;
      let htmlForContext = project.previewHtml;
      if (isPatchIntent && htmlForContext.length > MAX_PATCH_HTML_CHARS) {
        const head = htmlForContext.slice(0, 15_000);
        const tail = htmlForContext.slice(-3_000);
        htmlForContext = `${head}\n\n<!-- ... [${Math.round((htmlForContext.length - 18_000) / 1000)}KB truncated — context preserved, request your edit on visible code] ... -->\n\n${tail}`;
      }
      enrichedText = `[CURRENT APP CODE — START]
The app currently has the following complete HTML. ${isPatchIntent ? "Use the PATCH FORMAT (<<<REPLACE>>>...<<<WITH>>>...<<<END>>>) to return ONLY the changed sections — do NOT rewrite the full file." : "You MUST use this as your exact base. Return the complete updated HTML."}

\`\`\`html
${htmlForContext}
\`\`\`
[CURRENT APP CODE — END]

USER REQUEST: ${text}`;
    }
    return buildUserContent(enrichedText, attachments);
  };

  // ── Context trimming — keep the most recent N messages to stay within token limits ──
  // We keep recent messages (history window) + always include the new user message.
  // Large HTML content in assistant messages is truncated for context since the preview_html
  // column separately stores the latest HTML state.
  const HISTORY_WINDOW = 20; // max past turns to include
  const MAX_HIST_MSG_CHARS = 6_000; // truncate individual historic messages
  const trimmedHistory = existingMessages.slice(-HISTORY_WINDOW).map((m) => ({
    role: m.role as "user" | "assistant",
    // For older assistant messages containing full HTML, trim to save tokens
    content:
      m.role === "assistant" && m.content.length > MAX_HIST_MSG_CHARS
        ? m.content.slice(0, MAX_HIST_MSG_CHARS) +
          "\n\n[... content truncated for context ...]"
        : m.content,
  }));

  const messageHistory = [
    ...trimmedHistory,
    {
      role: "user" as const,
      content: buildFinalUserContent(body.content, body.attachments),
    },
  ] as Parameters<typeof anthropic.messages.stream>[0]["messages"];

  // ── Setup SSE ──
  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache, no-transform");
  res.setHeader("Connection", "keep-alive");
  res.setHeader("X-Accel-Buffering", "no"); // disable nginx proxy buffering
  res.flushHeaders();

  // Disable Nagle's algorithm so each res.write() is sent immediately
  // without waiting to accumulate data into a larger TCP packet.
  const socket = res.socket;
  if (socket) socket.setNoDelay(true);

  let clientDisconnected = false;
  req.on("close", () => { clientDisconnected = true; });

  const sendEvent = (data: object) => {
    if (!clientDisconnected) res.write(`data: ${JSON.stringify(data)}\n\n`);
  };

  // ── SSE heartbeat — prevents proxy/LB from closing idle connections ───────
  // Sends an SSE comment (ignored by frontend) every 15 s during long AI calls.
  const heartbeatInterval = setInterval(() => {
    if (!clientDisconnected) res.write(": heartbeat\n\n");
  }, 15_000);
  req.on("close", () => clearInterval(heartbeatInterval));

  let fullResponse = "";

  try {
    // ── Issue 14: Entrepreneur planning phase ──────────────────────────────
    // On first message in entrepreneur mode, emit a brief project plan before
    // the main AI response so the user sees structured thinking upfront.
    if (currentMode === "entrepreneur" && isFirstMessage) {
      sendEvent({
        type: "agent_phase",
        phase: "planning",
        message: `מנתח את הרעיון שלך...`,
      });

      const entrepreneurPlanPrompt = `You are a business and product planner for entrepreneurs.
The entrepreneur wants to build: "${body.content}"

Generate a brief structured plan in JSON:
{
  "business_idea": "one sentence summary",
  "target_audience": "who are the customers?",
  "key_features": ["feature 1", "feature 2", "feature 3"],
  "monetization": "how to make money",
  "tech_recommendation": "which stack to use and why"
}
Return ONLY the JSON, no markdown.`;

      try {
        const planMsg = await anthropic.messages.create({
          model: "claude-haiku-4-5-20251001",
          max_tokens: 600,
          messages: [{ role: "user", content: entrepreneurPlanPrompt }],
        });
        const planRaw =
          planMsg.content[0].type === "text" ? planMsg.content[0].text : "{}";
        const planJson = planRaw.match(/\{[\s\S]*\}/)?.[0];
        if (planJson) {
          const plan = JSON.parse(planJson) as Record<string, unknown>;
          sendEvent({ type: "entrepreneur_plan", plan });
        }
      } catch {
        // Non-fatal — proceed without plan
      }
      sendEvent({ type: "agent_phase", phase: null, message: null });
    }

    // ── T018: AI Image Generation Command ──────────────────────────────────
    // Detect /generate-image or /image command and return Pollinations.AI URL
    const imgMatch =
      body.content.match(/^\/(?:generate-image|image)\s+(.+)/i) ||
      body.content.match(
        /^(?:צור תמונה|generate image|create image|make image)\s+(.+)/i,
      );
    if (imgMatch) {
      const prompt = (imgMatch[1] ?? "").trim();
      const encodedPrompt = encodeURIComponent(prompt);
      const imageUrl = `https://image.pollinations.ai/prompt/${encodedPrompt}?width=1024&height=768&nologo=true&seed=${Date.now()}`;
      const replyText = `הנה התמונה שיצרתי:\n\n![${prompt}](${imageUrl})\n\n🎨 **תמונה שנוצרה ב-AI** — [פתח בגודל מלא](${imageUrl})`;
      sendEvent({ type: "text", content: replyText });
      fullResponse = replyText;
      // Save message to DB
      await db.insert(projectMessagesTable).values({
        projectId: project.id,
        role: "assistant",
        content: replyText,
      });
      sendEvent({ done: true, previewUpdated: false });
      res.end();
      return;
    }

    // ════════════════════════════════════════════════════════
    // INTENT ROUTING — handle action intents without AI generation
    // ════════════════════════════════════════════════════════

    // Always notify the frontend what intent was detected
    sendEvent({
      type: "intent_detected",
      intent: detectedIntent.intent,
      label: detectedIntent.label,
      emoji: detectedIntent.emoji,
    });

    // ── Deploy intent: full Netlify deploy with deploymentsTable record ──
    if (detectedIntent.intent === "deploy") {
      const netlifyToken = (
        body.integrations as Record<string, string> | undefined
      )?.netlifyToken;
      if (!netlifyToken) {
        const replyText =
          "כדי לפרסם, חבר את Netlify בדף Integrations עם Personal Access Token. לאחר מכן שלח שוב 'פרסם'.";
        sendEvent({ type: "text", content: replyText });
        await db.insert(projectMessagesTable).values({
          projectId: project.id,
          role: "assistant",
          content: replyText,
        });
        sendEvent({
          done: true,
          previewUpdated: false,
          action: "connect_netlify",
        });
        res.end();
        return;
      }

      const isReactProject =
        project.stack === "react" || project.stack === "nextjs";
      const projectFiles = isReactProject
        ? await db
            .select()
            .from(projectFilesTable)
            .where(eq(projectFilesTable.projectId, params.id))
        : [];
      const hasContent = project.previewHtml || projectFiles.length > 0;

      if (!hasContent) {
        const replyText =
          "אין עדיין קוד לפרסם — בנה קודם את הפרויקט ואז אפרסם אותו.";
        sendEvent({ type: "text", content: replyText });
        await db.insert(projectMessagesTable).values({
          projectId: project.id,
          role: "assistant",
          content: replyText,
        });
        sendEvent({ done: true, previewUpdated: false });
        res.end();
        return;
      }

      // Create a deploymentsTable record so it shows in the Deploy panel
      const [deployRecord] = await db
        .insert(deploymentsTable)
        .values({
          projectId: project.id,
          provider: "netlify",
          status: "building",
        })
        .returning();

      sendEvent({ type: "text", content: "🚀 מפרסם את הפרויקט ב-Netlify..." });

      try {
        const slug = (project.title || "builder-app")
          .toLowerCase()
          .replace(/[^a-z0-9]+/g, "-")
          .replace(/^-|-$/g, "")
          .slice(0, 40);

        // Create Netlify site
        const siteRes = await fetch("https://api.netlify.com/api/v1/sites", {
          method: "POST",
          headers: {
            Authorization: `Bearer ${netlifyToken}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            name: `${slug}-${deployRecord.id}`,
            custom_domain: null,
          }),
        });
        if (!siteRes.ok) {
          const siteErr = (await siteRes.json().catch(() => ({}))) as Record<
            string,
            string
          >;
          throw new Error(
            siteErr["message"] ?? "Failed to create Netlify site",
          );
        }
        const site = (await siteRes.json()) as {
          id: string;
          ssl_url: string;
          url: string;
        };

        sendEvent({ type: "text", content: "📦 מכין את קבצי הפרויקט..." });

        // Build ZIP — handle both HTML and React projects
        let zipBuffer: Buffer;
        if (isReactProject && projectFiles.length > 0) {
          // For React projects: bundle files into a simple single-file deploy
          const entryFile =
            projectFiles.find((f) => f.isEntrypoint) || projectFiles[0];
          const allContent = projectFiles
            .map((f) => `/* ${f.path} */\n${f.content}`)
            .join("\n\n");
          const htmlShell = `<!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${project.title ?? "App"}</title></head><body><div id="root"></div><script type="module">${allContent}</script></body></html>`;
          zipBuffer = await createZip({ "index.html": htmlShell });
          void entryFile; // suppress unused warning
        } else {
          zipBuffer = await createZip({ "index.html": project.previewHtml! });
        }

        // Upload to Netlify
        const deployRes = await fetch(
          `https://api.netlify.com/api/v1/sites/${site.id}/deploys`,
          {
            method: "POST",
            headers: {
              Authorization: `Bearer ${netlifyToken}`,
              "Content-Type": "application/zip",
            },
            body: zipBuffer,
          },
        );
        if (!deployRes.ok) {
          const depErr = (await deployRes.json().catch(() => ({}))) as Record<
            string,
            string
          >;
          throw new Error(depErr["message"] ?? "Deploy upload failed");
        }
        const deploy = (await deployRes.json()) as {
          id: string;
          deploy_ssl_url?: string;
          ssl_url?: string;
          state?: string;
        };

        // Poll Netlify for ready state (up to 60 seconds)
        sendEvent({ type: "text", content: "⏳ ממתין לאישור Netlify..." });
        let liveUrl =
          deploy.deploy_ssl_url || deploy.ssl_url || site.ssl_url || site.url;
        if (deploy.state !== "ready" && deploy.id) {
          for (let i = 0; i < 12; i++) {
            await new Promise((r) => setTimeout(r, 5000));
            const pollRes = await fetch(
              `https://api.netlify.com/api/v1/sites/${site.id}/deploys/${deploy.id}`,
              {
                headers: { Authorization: `Bearer ${netlifyToken}` },
              },
            );
            if (pollRes.ok) {
              const pollData = (await pollRes.json()) as {
                state?: string;
                deploy_ssl_url?: string;
                ssl_url?: string;
              };
              if (pollData.state === "ready") {
                liveUrl =
                  pollData.deploy_ssl_url || pollData.ssl_url || liveUrl;
                break;
              }
            }
          }
        }

        // Update deploymentsTable record
        await db
          .update(deploymentsTable)
          .set({
            status: "live",
            url: liveUrl,
            siteId: site.id,
            deployId: deploy.id,
          })
          .where(eq(deploymentsTable.id, deployRecord.id));
        // Save last deploy URL to project
        await db
          .update(projectsTable)
          .set({ lastDeployUrl: liveUrl, updatedAt: new Date() })
          .where(eq(projectsTable.id, project.id));

        const replyText = `✅ **הפרויקט פורסם בהצלחה!**\n\n🌐 כתובת חיה: [${liveUrl}](${liveUrl})\n\nהאתר שלך נמצא עכשיו ברשת ומוכן לשיתוף. תוכל לראות את ההיסטוריה של הפרסומים בלשונית Deploy.`;
        sendEvent({ type: "text", content: replyText });
        await db.insert(projectMessagesTable).values({
          projectId: project.id,
          role: "assistant",
          content: replyText,
        });
        sendEvent({
          done: true,
          previewUpdated: false,
          action: "deployed",
          deployUrl: liveUrl,
        });
      } catch (deployErr) {
        const msg =
          deployErr instanceof Error ? deployErr.message : "שגיאת פרסום";
        // Mark deploy as failed
        await db
          .update(deploymentsTable)
          .set({ status: "failed", error: msg })
          .where(eq(deploymentsTable.id, deployRecord.id))
          .catch(() => {});
        const replyText = `❌ הפרסום נכשל: ${msg}. בדוק את ה-Netlify Token בדף Integrations.`;
        sendEvent({ type: "text", content: replyText });
        await db.insert(projectMessagesTable).values({
          projectId: project.id,
          role: "assistant",
          content: replyText,
        });
        sendEvent({ done: true, previewUpdated: false });
      }
      res.end();
      return;
    }

    // ── Git push intent: sync to GitHub, persist repoUrl for reuse ───────
    if (detectedIntent.intent === "git_push") {
      const githubToken = (
        body.integrations as Record<string, string> | undefined
      )?.githubToken;
      if (!githubToken) {
        const replyText =
          "כדי לסנכרן GitHub, חבר את GitHub בדף Integrations עם Personal Access Token (הרשאות: repo). לאחר מכן שלח שוב 'push to GitHub'.";
        sendEvent({ type: "text", content: replyText });
        await db.insert(projectMessagesTable).values({
          projectId: project.id,
          role: "assistant",
          content: replyText,
        });
        sendEvent({
          done: true,
          previewUpdated: false,
          action: "connect_github",
        });
        res.end();
        return;
      }
      // Use stored repo name so subsequent pushes go to the same repo
      const existingRepoName = project.githubRepoName ?? undefined;
      sendEvent({
        type: "text",
        content: existingRepoName
          ? `מעדכן רפוזיטורי ${existingRepoName} ב-GitHub...`
          : "יוצר רפוזיטורי חדש ב-GitHub...",
      });
      try {
        const result = await syncProjectToGitHub(
          params.id,
          githubToken,
          existingRepoName,
        );
        // Persist the repo URL and name so the next push reuses the same repo
        await db
          .update(projectsTable)
          .set({
            githubRepoUrl: result.repoUrl,
            githubRepoName: result.repoName,
            updatedAt: new Date(),
          })
          .where(eq(projectsTable.id, project.id));
        const action = result.isNew ? "יצרתי" : "עדכנתי";
        const fileWord = result.filesSync === 1 ? "קובץ" : "קבצים";
        const replyText = `✅ **GitHub מסונכרן!**\n\n📦 ${action} רפוזיטורי: [${result.owner}/${result.repoName}](${result.repoUrl})\n🗂️ ${result.filesSync} ${fileWord} סונכרנו\n\nהקוד שלך ב-GitHub מעודכן. הפעם הבאה שתבקש לסנכרן, אעדכן את אותו ה-repo.`;
        sendEvent({ type: "text", content: replyText });
        await db.insert(projectMessagesTable).values({
          projectId: project.id,
          role: "assistant",
          content: replyText,
        });
        sendEvent({
          done: true,
          previewUpdated: false,
          action: "git_synced",
          repoUrl: result.repoUrl,
        });
      } catch (gitErr) {
        const msg = gitErr instanceof Error ? gitErr.message : "שגיאת GitHub";
        const replyText = `❌ הסנכרון נכשל: ${msg}`;
        sendEvent({ type: "text", content: replyText });
        await db.insert(projectMessagesTable).values({
          projectId: project.id,
          role: "assistant",
          content: replyText,
        });
        sendEvent({ done: true, previewUpdated: false });
      }
      res.end();
      return;
    }

    // ── Inspect intent: rich project state summary ───────────────────────
    if (detectedIntent.intent === "inspect" && hasExistingCode) {
      // Load files for React projects
      const inspectFiles =
        project.stack === "react" || project.stack === "nextjs"
          ? await db
              .select({
                path: projectFilesTable.path,
                language: projectFilesTable.language,
              })
              .from(projectFilesTable)
              .where(eq(projectFilesTable.projectId, params.id))
          : [];

      const fileList =
        inspectFiles.length > 0
          ? inspectFiles.map((f) => `  - ${f.path} (${f.language})`).join("\n")
          : "";

      const gitStatus = project.githubRepoUrl
        ? `GitHub: מחובר — ${project.githubRepoUrl}`
        : "GitHub: לא מסונכרן";

      const deployStatus = project.lastDeployUrl
        ? `Deploy: פורסם — ${project.lastDeployUrl}`
        : "Deploy: לא פורסם עדיין";

      const projectSummary = [
        `כותרת: ${project.title}`,
        `Stack: ${project.stack ?? "html"}`,
        project.previewHtml
          ? `גודל קוד: ${Math.round(project.previewHtml.length / 1024)}KB`
          : "",
        fileList ? `קבצים:\n${fileList}` : "",
        `הודעות בצ'אט: ${existingMessages.length}`,
        gitStatus,
        deployStatus,
        project.previewHtml
          ? `תחילת הקוד:\n\`\`\`html\n${project.previewHtml.slice(0, 500)}\n\`\`\``
          : "",
      ]
        .filter(Boolean)
        .join("\n");

      const inspectStream = anthropic.messages.stream({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 600,
        system:
          "You are helping a user understand their current project state. Be concise, friendly, and use bullet points. Always answer in Hebrew. Include the GitHub and deploy status in your summary.",
        messages: [
          {
            role: "user",
            content: `סכם את המצב הנוכחי של הפרויקט:\n${projectSummary}\n\nשאלת המשתמש: ${body.content}`,
          },
        ],
      });

      for await (const chunk of inspectStream) {
        if (
          chunk.type === "content_block_delta" &&
          chunk.delta.type === "text_delta"
        ) {
          fullResponse += chunk.delta.text;
          sendEvent({ type: "text", content: chunk.delta.text });
        }
      }

      await db.insert(projectMessagesTable).values({
        projectId: project.id,
        role: "assistant",
        content: fullResponse,
      });
      sendEvent({ done: true, previewUpdated: false });
      res.end();
      return;
    }

    // ════════════════════════════════════════════════════════
    // PLANNING PHASE — ask clarifying questions, no code yet
    // ════════════════════════════════════════════════════════
    if (usePlanningPhase) {
      sendEvent({
        type: "planning_start",
        message: "מגבש שאלות לפני הבנייה...",
      });

      const planningStream = anthropic.messages.stream({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 800,
        system: PLANNING_SYSTEM_PROMPT,
        messages: [{ role: "user", content: body.content }],
      });

      for await (const chunk of planningStream) {
        if (
          chunk.type === "content_block_delta" &&
          chunk.delta.type === "text_delta"
        ) {
          const text = chunk.delta.text;
          fullResponse += text;
          sendEvent({ type: "text", content: text });
        }
      }

      // Save AI planning response
      await db.insert(projectMessagesTable).values({
        projectId: project.id,
        role: "assistant",
        content: fullResponse,
      });

      sendEvent({ type: "planning_done" });
      sendEvent({ done: true, previewUpdated: false });
      res.end();
      return;
    }

    // ════════════════════════════════════════════════════════
    // SPEC GENERATION PHASE — create structured Product Spec after Q&A
    // existingMessages = [userRequest, aiPlanningQuestions]
    // currentMessage = user's answers to the questions
    // ════════════════════════════════════════════════════════
    if (useSpecGeneration) {
      sendEvent({
        type: "spec_start",
        message: "מנסח מפרט מוצר מפורט בהתבסס על תשובותיך...",
      });

      const specStream = anthropic.messages.stream({
        model: "claude-haiku-4-5-20251001",
        max_tokens: 1400,
        system: PRODUCT_SPEC_SYSTEM_PROMPT,
        messages: [
          {
            role: "user",
            content: existingMessages[0]?.content ?? body.content,
          },
          { role: "assistant", content: existingMessages[1]?.content ?? "" },
          { role: "user", content: body.content },
        ],
      });

      for await (const chunk of specStream) {
        if (
          chunk.type === "content_block_delta" &&
          chunk.delta.type === "text_delta"
        ) {
          const text = chunk.delta.text;
          fullResponse += text;
          sendEvent({ type: "text", content: text });
        }
      }

      await db.insert(projectMessagesTable).values({
        projectId: project.id,
        role: "assistant",
        content: fullResponse,
      });

      sendEvent({ type: "spec_done" });
      sendEvent({ done: true, previewUpdated: false });
      res.end();
      return;
    }

    // ── Command 1: Multi-Agent Pipeline ────────────────────────────────────
    // Only runs for CREATE intent — edit/fix/inspect don't benefit from
    // architecture/UI planning agents and they add latency + noise.
    let agentContext = "";
    const isCreateIntent = detectedIntent.intent === "create";
    const isComplexRequest =
      isCreateIntent &&
      (isFirstMessage ||
        isPlanningAnswerMessage ||
        (body.content.length > 350 && body.content.split(" ").length > 25));

    if (isComplexRequest && !agentFlow) {
      sendEvent({
        type: "pipeline_start",
        message: "מנתח בקשה עם 4 agents מתמחים...",
      });

      // Build the full request context — include planning Q&A + spec if available
      const fullRequestContext = isAfterSpecPhase
        ? `ORIGINAL REQUEST: ${existingMessages[0]?.content ?? ""}

PLANNING Q&A:
${existingMessages[1]?.content ?? ""}

USER ANSWERS:
${existingMessages[2]?.content ?? ""}

CONFIRMED PRODUCT SPEC:
${existingMessages[3]?.content ?? ""}

USER CONFIRMATION: ${body.content}

Build exactly what the Product Spec says. Follow the design style, pages, and features listed.`
        : isPlanningAnswerMessage
          ? `Initial request: ${existingMessages[0]?.content ?? ""}\n\nClarification answers: ${body.content}`
          : body.content;

      // Run architecture agent first (sequential — others depend on its result)
      const archResult = await runArchitectureAgent(
        fullRequestContext,
        project.stack ?? "html",
        currentMode,
      );
      sendEvent({
        type: "pipeline_step",
        step: "architecture",
        data: archResult,
      });

      // Run UI, Security and Performance agents in parallel (Command 1 requirement)
      const [uiResult, secResult, perfResult] = await Promise.all([
        runUiAgent(fullRequestContext, currentMode),
        runSecurityAgent(fullRequestContext),
        runPerformanceAgent(fullRequestContext),
      ]);

      sendEvent({ type: "pipeline_step", step: "ui", data: uiResult });
      sendEvent({ type: "pipeline_step", step: "security", data: secResult });
      sendEvent({
        type: "pipeline_step",
        step: "performance",
        data: perfResult,
      });

      const fullAnalysis: AgentAnalysis = {
        architecture: archResult,
        ui: uiResult,
        security: secResult,
        performance: perfResult,
      };

      agentContext = buildAgentContext(fullAnalysis);

      // Save decision log to project_dna (fire-and-forget)
      const decisionEntry = {
        timestamp: new Date().toISOString(),
        userMessage: body.content.slice(0, 200),
        architecture: archResult.reasoning,
        design: uiResult.designNotes,
        security: secResult.mitigations.slice(0, 2),
        performance: perfResult.patterns.slice(0, 2),
      };
      const existingLog = (projectDna?.decisionLog as unknown[]) ?? [];
      db.update(projectDnaTable)
        .set({
          decisionLog: [...existingLog, decisionEntry].slice(
            -20,
          ) as unknown as Record<string, unknown>[],
          updatedAt: new Date(),
        })
        .where(eq(projectDnaTable.projectId, params.id))
        .catch(() => {});

      sendEvent({
        type: "pipeline_done",
        message: "ניתוח הושלם — בונה עכשיו...",
      });
    }

    // For edit/fix intents: use a focused system prompt — no design engine overhead.
    // The model only needs to know how to do the patch/edit correctly, not build from scratch.
    const isEditOrFix =
      detectedIntent.intent === "edit" || detectedIntent.intent === "fix";

    const baseSystemPrompt = isEditOrFix
      ? `You are an expert web developer making targeted edits to an existing project.
RESPOND IN THE SAME LANGUAGE AS THE USER (Hebrew → Hebrew, English → English).

EDITING RULES (MANDATORY):
• Read the [CURRENT APP CODE] carefully before touching anything
• Change ONLY what the user explicitly asked to change
• Preserve ALL existing features, styles, content, and structure
• Never remove or restructure things that were not mentioned
• For HTML projects: use the patch format (<<<REPLACE>>>...<<<WITH>>>...<<<END>>>) for surgical changes
• For React/multi-file projects: output ONLY the changed files
• Briefly explain in the user's language what you changed and why — BEFORE the code`
      : getSystemPrompt(
          currentMode,
          body.integrations as Record<string, string> | undefined,
          project.type,
          project.stack ?? "html",
          detectedIntent.intent,
        );

    // Only inject landing-page design rules when the request explicitly signals a marketing site
    const needsLandingPageDesign =
      !isEditOrFix &&
      isCreateIntent &&
      isMarketingPageRequest(body.content) &&
      (project.stack ?? "html") === "html";

    const systemPrompt =
      baseSystemPrompt +
      (needsLandingPageDesign ? "\n" + LANDING_PAGE_DESIGN_RULES : "") +
      // Skip DNA/memory noise for edit/fix — not relevant when patching
      (!isEditOrFix && userDnaContext ? "\n" + userDnaContext : "") +
      (!isEditOrFix && dnaContext ? "\n" + dnaContext : "") +
      (!isEditOrFix ? memoryChunkContext : "") +
      agentContext +
      getIntentSystemAddition(detectedIntent.intent);

    // ══════════════════════════════════════════════════════════════════════════
    // AGENT FLOW — Step-by-step building, merged into the regular chat SSE
    // Triggered when the frontend sends agentFlow: true in the message body.
    // ══════════════════════════════════════════════════════════════════════════
    if (agentFlow) {
      const existingHtml = project.previewHtml || "";

      // ── Step 1: Plan the work ────────────────────────────────────────────
      sendEvent({
        type: "agent_phase",
        phase: "planning",
        message: "מתכנן שלבים...",
      });

      let plan: {
        steps: Array<{
          id: number;
          emoji: string;
          title: string;
          prompt: string;
        }>;
      };
      try {
        const planRes = await anthropic.messages.create({
          model: "claude-haiku-4-5-20251001",
          max_tokens: 1000,
          system: `You are a task planner for an AI app builder. Break the user's task into 3-5 focused implementation steps.
Return ONLY valid JSON with no other text: {"steps":[{"id":1,"emoji":"🏗️","title":"Hebrew title max 30 chars","prompt":"Detailed English implementation instruction for Claude Sonnet"}]}
Emojis: 🏗️ for layout/structure, 🎨 for styling/design, ⚡ for functionality/JS, 🔌 for API/data, 🧪 for testing/fixes.`,
          messages: [
            {
              role: "user",
              content: `Task: ${body.content}\nExisting code: ${existingHtml ? "YES — must modify and preserve existing content" : "NONE — build from scratch"}`,
            },
          ],
        });
        const planText =
          planRes.content[0].type === "text" ? planRes.content[0].text : "";
        const m = planText.match(/\{[\s\S]*\}/);
        plan = m
          ? JSON.parse(m[0])
          : {
              steps: [
                {
                  id: 1,
                  emoji: "🚀",
                  title: body.content.slice(0, 30),
                  prompt: body.content,
                },
              ],
            };
        if (!Array.isArray(plan.steps) || plan.steps.length === 0)
          throw new Error("empty plan");
      } catch {
        plan = {
          steps: [
            {
              id: 1,
              emoji: "🚀",
              title: body.content.slice(0, 30),
              prompt: body.content,
            },
          ],
        };
      }

      sendEvent({
        type: "agent_plan",
        steps: plan.steps.map((s) => ({
          id: s.id,
          emoji: s.emoji,
          title: s.title,
        })),
      });

      // ── Step 2: Execute each step with Sonnet, streaming ────────────────
      let currentHtml = existingHtml;

      for (const step of plan.steps) {
        sendEvent({
          type: "agent_step_start",
          stepId: step.id,
          title: step.title,
          emoji: step.emoji,
        });

        const stepUserContent = currentHtml
          ? `[CURRENT APP — START]\n\`\`\`html\n${currentHtml}\n\`\`\`\n[CURRENT APP — END]\n\nIMPORTANT: Use the code above as your exact base. Return the COMPLETE updated HTML file.\n\nSTEP ${step.id}: ${step.prompt}`
          : `STEP ${step.id}: ${step.prompt}`;

        const stepHistory = [...messageHistory];
        // Replace the last user message with the enriched step content
        if (
          stepHistory.length > 0 &&
          stepHistory[stepHistory.length - 1].role === "user"
        ) {
          stepHistory[stepHistory.length - 1] = {
            role: "user",
            content: stepUserContent,
          };
        } else {
          stepHistory.push({ role: "user", content: stepUserContent });
        }

        const stepStream = anthropic.messages.stream({
          model: "claude-sonnet-4-5",
          max_tokens: 8192,
          system: systemPrompt,
          messages: stepHistory,
        });

        let stepFull = "";
        let stepPatchDepth = 0;
        for await (const chunk of stepStream) {
          if (clientDisconnected) break;
          if (
            chunk.type === "content_block_delta" &&
            chunk.delta.type === "text_delta"
          ) {
            const text = chunk.delta.text;
            stepFull += text;
            fullResponse += text;
            const totalFences = (fullResponse.match(/```/g) ?? []).length;
            if (text.includes("<<<REPLACE>>>")) stepPatchDepth++;
            if (text.includes("<<<END>>>"))
              stepPatchDepth = Math.max(0, stepPatchDepth - 1);
            const inCode = totalFences % 2 === 1 || stepPatchDepth > 0;
            sendEvent({ type: inCode ? "code" : "text", content: text });
            sendEvent({ type: "agent_step_stream", stepId: step.id, text });
          }
        }

        // Extract HTML from this step's output
        const htmlRe = /```html\r?\n([\s\S]*?)\n```/gi;
        let bestHtml: string | null = null;
        let hm: RegExpExecArray | null;
        while ((hm = htmlRe.exec(stepFull)) !== null) {
          const c = hm[1].trim();
          if (c.length > (bestHtml?.length ?? 0)) bestHtml = c;
        }
        if (bestHtml) currentHtml = autoCdnInject(bestHtml);

        sendEvent({ type: "agent_step_done", stepId: step.id });
      }

      // ── Step 3: Auto-fix ─────────────────────────────────────────────────
      if (useAutoFix && currentHtml) {
        for (let iter = 1; iter <= 2; iter++) {
          sendEvent({ type: "agent_fix_start", iteration: iter });
          let fixIssues: string[] = [];
          let fixedHtml: string | null = null;
          try {
            const fixRes = await anthropic.messages.create({
              model: "claude-haiku-4-5-20251001",
              max_tokens: 8000,
              system: `Review the HTML/CSS/JS code for bugs, broken references, or missing logic. 
Output a JSON object: {"issues":["desc1","desc2"]} listing any problems found. If NO issues: {"issues":[]}.
If issues exist, also output the complete corrected HTML in a \`\`\`html block after the JSON.`,
              messages: [
                {
                  role: "user",
                  content: `Review and fix:\n\`\`\`html\n${currentHtml}\n\`\`\``,
                },
              ],
            });
            const fixText =
              fixRes.content[0].type === "text" ? fixRes.content[0].text : "";
            const issueMatch = fixText.match(/\{[\s\S]*?"issues"[\s\S]*?\}/);
            if (issueMatch) {
              try {
                fixIssues = JSON.parse(issueMatch[0]).issues ?? [];
              } catch {
                /* ignore */
              }
            }
            const fixHtmlRegex = /```html\r?\n([\s\S]*?)\n```/gi;
            let bestFix: string | null = null;
            let fixM: RegExpExecArray | null;
            while ((fixM = fixHtmlRegex.exec(fixText)) !== null) {
              const c = fixM[1].trim();
              if (c.length > (bestFix?.length ?? 0)) bestFix = c;
            }
            if (bestFix) fixedHtml = autoCdnInject(bestFix);
          } catch {
            /* non-critical */
          }

          if (fixIssues.length === 0) {
            sendEvent({
              type: "agent_fix_done",
              iteration: iter,
              fixed: false,
              issues: [],
            });
            break;
          }
          if (fixedHtml) {
            currentHtml = fixedHtml;
            sendEvent({
              type: "agent_fix_done",
              iteration: iter,
              fixed: true,
              issues: fixIssues,
            });
          } else {
            sendEvent({
              type: "agent_fix_done",
              iteration: iter,
              fixed: false,
              issues: fixIssues,
            });
            break;
          }
        }
      }

      // ── Step 4: Save everything ──────────────────────────────────────────
      await db.insert(projectMessagesTable).values({
        projectId: params.id,
        role: "assistant",
        content:
          fullResponse ||
          `[סוכן] ביצע: ${body.content}\n\n\`\`\`html\n${currentHtml}\n\`\`\``,
      });

      const agentAllMessages = await db
        .select()
        .from(projectMessagesTable)
        .where(eq(projectMessagesTable.projectId, params.id));
      const agentSkillScore = calculateSkillScore(agentAllMessages);

      const agentUpdate: Record<string, unknown> = {
        updatedAt: new Date(),
        skillScore: agentSkillScore,
      };
      if (currentHtml) agentUpdate.previewHtml = currentHtml;

      await db
        .update(projectsTable)
        .set(agentUpdate)
        .where(eq(projectsTable.id, params.id));

      if (currentHtml) {
        await db
          .insert(projectFilesTable)
          .values({
            projectId: params.id,
            path: "index.html",
            content: currentHtml,
            language: "html",
            isEntrypoint: true,
          })
          .onConflictDoUpdate({
            target: [projectFilesTable.projectId, projectFilesTable.path],
            set: { content: currentHtml, updatedAt: new Date() },
          });

        const msgCountForSnap = agentAllMessages.filter(
          (m) => m.role === "user",
        ).length;
        await db.insert(projectSnapshotsTable).values({
          projectId: params.id,
          html: currentHtml,
          label: `גרסה ${msgCountForSnap} (סוכן)`,
        });
      }

      if (currentHtml)
        broadcastProjectUpdate(String(params.id), { previewUpdated: true });

      extractAndSaveDNA(
        params.id,
        body.content,
        fullResponse,
        currentMode,
        detectedIntent.intent,
      ).catch(() => {});
      extractAndSaveMemoryChunks(
        params.id,
        body.content,
        fullResponse,
        rawChunks,
        detectedIntent.intent,
      ).catch(() => {});

      sendEvent({
        done: true,
        previewUpdated: !!currentHtml,
        agentDone: true,
        stepsCompleted: plan.steps.length,
        skillScore: agentSkillScore,
        detectedMode: isFirstMessage ? currentMode : undefined,
      });
      return;
    }
    // ══════════════════════════════════════════════════════════════════════════
    // END AGENT FLOW
    // ══════════════════════════════════════════════════════════════════════════

    // ── Semantic cache check (prompt_cache table) ────────────────────────────
    // Key includes projectId to prevent cross-project cache collisions,
    // plus intent so "fix a bug" and "build a homepage" never share an entry.
    const currentHtmlHash = project.previewHtml
      ? createHash("sha256").update(project.previewHtml.slice(0, 2000)).digest("hex").slice(0, 16)
      : "empty";
    const cacheKey = createHash("sha256")
      .update([
        String(params.id),
        body.content.slice(0, 500),
        currentMode,
        project.stack ?? "html",
        detectedIntent.intent,
        currentHtmlHash,
        isFirstMessage ? "new" : "existing",
      ].join("|"))
      .digest("hex");

    const [cachedEntry] = await db
      .select()
      .from(promptCacheTable)
      .where(eq(promptCacheTable.hash, cacheKey))
      .catch(() => [null]);

    if (cachedEntry) {
      // Stream cached response with correct code/text classification
      const chunks = cachedEntry.response.match(/.{1,100}/g) ?? [
        cachedEntry.response,
      ];
      let cachedPatchDepth = 0;
      for (const chunk of chunks) {
        fullResponse += chunk;
        // Apply the same fence/patch classification as the live stream
        const totalFences = (fullResponse.match(/```/g) ?? []).length;
        if (chunk.includes("<<<REPLACE>>>")) cachedPatchDepth++;
        if (chunk.includes("<<<END>>>")) cachedPatchDepth = Math.max(0, cachedPatchDepth - 1);
        const inCode = totalFences % 2 === 1 || cachedPatchDepth > 0;
        sendEvent({ type: inCode ? "code" : "text", content: chunk });
      }
      await db.insert(projectMessagesTable).values({
        projectId: project.id,
        role: "assistant",
        content: fullResponse,
      });
      sendEvent({ done: true, previewUpdated: false, fromCache: true });
      res.end();
      return;
    }

    const getLatencyMs = startTimer();
    const stream = anthropic.messages.stream({
      model: "claude-sonnet-4-5",
      max_tokens: 8192,
      system: systemPrompt,
      messages: messageHistory,
    });

    // Track fence depth using accumulated fullResponse — safe across chunk splits.
    let patchDepth = 0; // open <<<REPLACE>>> blocks not yet closed by <<<END>>>

    for await (const chunk of stream) {
      if (clientDisconnected) break;
      if (
        chunk.type === "content_block_delta" &&
        chunk.delta.type === "text_delta"
      ) {
        const text = chunk.delta.text;
        fullResponse += text;

        // Count ALL ``` in accumulated response — correct across chunk boundaries
        const totalFences = (fullResponse.match(/```/g) ?? []).length;

        // Count patch-format markers so they're hidden from chat display
        if (text.includes("<<<REPLACE>>>")) patchDepth++;
        if (text.includes("<<<END>>>"))
          patchDepth = Math.max(0, patchDepth - 1);

        const inCode = totalFences % 2 === 1 || patchDepth > 0;

        // Send typed SSE event so frontend can route text vs. code separately
        sendEvent({ type: inCode ? "code" : "text", content: text });
      }
    }

    if (clientDisconnected) { res.end(); return; }

    // ── Auto-continuation when output token limit hit mid-code ──────────────
    // If the model stopped because it hit max_tokens (not end_turn), and we're
    // generating HTML, automatically request a continuation so the code is complete.
    const isReactStackEarly =
      project.stack === "react" || project.stack === "nextjs";
    if (!isReactStackEarly) {
      try {
        const finalMsg = await stream.finalMessage();
        if (finalMsg.stop_reason === "max_tokens") {
          // Detect whether we're inside an open code block that needs completing
          const isInsideCodeBlock = ((fullResponse.match(/```/g) ?? []).length) % 2 === 1;
          const lastChars = fullResponse.slice(-300);

          const continuationMessages: {
            role: "user" | "assistant";
            content: string;
          }[] = [
            ...messageHistory.map((m) => ({
              role: m.role as "user" | "assistant",
              content:
                typeof m.content === "string"
                  ? m.content
                  : JSON.stringify(m.content),
            })),
            { role: "assistant", content: fullResponse },
            {
              role: "user",
              content: isInsideCodeBlock
                ? "המשך את הקוד בדיוק מהמקום שעצרת. אל תוסיף הסבר — רק המשך את הקוד."
                : `המשך בדיוק מהמקום שעצרת. הטקסט האחרון שכתבת: "${lastChars}"`,
            },
          ];

          const continuationStream = anthropic.messages.stream({
            model: "claude-sonnet-4-5",
            max_tokens: 8192,
            system: systemPrompt,
            messages: continuationMessages,
          });

          for await (const chunk of continuationStream) {
            if (clientDisconnected) break;
            if (
              chunk.type === "content_block_delta" &&
              chunk.delta.type === "text_delta"
            ) {
              const text = chunk.delta.text;
              fullResponse += text;

              const totalFences = (fullResponse.match(/```/g) ?? []).length;
              if (text.includes("<<<REPLACE>>>")) patchDepth++;
              if (text.includes("<<<END>>>"))
                patchDepth = Math.max(0, patchDepth - 1);
              const inCode = totalFences % 2 === 1 || patchDepth > 0;

              sendEvent({ type: inCode ? "code" : "text", content: text });
            }
          }
        }
      } catch {
        /* non-critical — extraction will still work on what we have */
      }
    }

    // ── Extract HTML preview (for HTML/Node/FastAPI stacks) ──
    const isReactStack =
      project.stack === "react" || project.stack === "nextjs";

    // ── Patch-format application (for fix/edit intents on HTML projects) ─────
    // AI may return <<<REPLACE>>>old<<<WITH>>>new<<<END>>> blocks instead of full HTML
    const applyHtmlPatches = (
      response: string,
      baseHtml: string,
    ): string | null => {
      const patchRegex =
        /<<<REPLACE>>>([\s\S]*?)<<<WITH>>>([\s\S]*?)<<<END>>>/g;
      let match: RegExpExecArray | null;
      const patches: Array<{ from: string; to: string }> = [];
      while ((match = patchRegex.exec(response)) !== null) {
        patches.push({ from: match[1].trim(), to: match[2].trim() });
      }
      if (patches.length === 0) return null;
      let result = baseHtml;
      for (const { from, to } of patches) {
        if (!result.includes(from)) {
          // Try a looser match ignoring leading/trailing whitespace per line
          const normalized = from.replace(/[ \t]+/g, " ").trim();
          const normResult = result.replace(/[ \t]+/g, " ");
          if (!normResult.includes(normalized)) continue; // skip unmatched patch
          result = result.replace(
            new RegExp(normalized.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")),
            to,
          );
        } else {
          result = result.replace(from, to);
        }
      }
      return result !== baseHtml ? result : null; // null if nothing changed
    };

    const extractedHtml = (() => {
      if (isReactStack) return null; // React uses file manifest, not HTML

      // ── Try patch format first (fix/edit intents) ──────────────────────────
      const existingBase = project.previewHtml ?? "";
      if (
        existingBase &&
        (detectedIntent.intent === "fix" || detectedIntent.intent === "edit")
      ) {
        const patched = applyHtmlPatches(fullResponse, existingBase);
        if (patched) return patched;
      }

      // Helper: extract the largest complete html block from a response.
      // Uses a non-greedy match that looks for closing fence at start-of-line
      // to avoid early termination on backticks inside <script> tags.
      const extractFencedHtml = (text: string): string | null => {
        // Collect ALL ```html...``` fenced blocks and return the longest
        const regex = /```html\r?\n([\s\S]*?)\n```/gi;
        let best: string | null = null;
        let match: RegExpExecArray | null;
        while ((match = regex.exec(text)) !== null) {
          const candidate = match[1].trim();
          if (candidate.length > (best?.length ?? 0)) best = candidate;
        }
        return best;
      };

      // Try standard ```html ... ``` block
      const m = extractFencedHtml(fullResponse);
      if (m) return m;

      // Try any fenced block that starts with <!DOCTYPE or <html
      const m2 = fullResponse.match(
        /```[^\n]*\r?\n((?:<!DOCTYPE|<html)[\s\S]*?)\n```/i,
      );
      if (m2?.[1]?.trim()) return m2[1].trim();

      // Try bare HTML block (no code fence) — look for DOCTYPE or <html wrapper
      const m3 = fullResponse.match(/(<!DOCTYPE\s+html[\s\S]*?<\/html>)/i);
      if (m3?.[1]?.trim()) return m3[1].trim();

      // Last resort: any <html>...</html> block
      const m4 = fullResponse.match(/(<html[\s\S]*?<\/html>)/i);
      if (m4?.[1]?.trim()) return m4[1].trim();

      // Truncated response fallback: response started with ```html but was cut off before closing ```
      // (happens when output tokens limit is reached mid-generation)
      const truncatedMatch = fullResponse.match(
        /```(?:html)?\r?\n((?:<!DOCTYPE|<html)[\s\S]+)$/i,
      );
      if (truncatedMatch?.[1]?.trim()) {
        let partial = truncatedMatch[1].trim();
        // Try to repair — close any open tags we can detect
        if (!/<\/html>/i.test(partial)) {
          if (!/<\/body>/i.test(partial)) partial += "\n</body>";
          partial += "\n</html>";
        }
        return partial;
      }

      return null;
    })();

    // ── Extract React multi-file manifest ── (Issue 22: fallback parsing)
    interface ExtractedFile {
      path: string;
      content: string;
      language: string;
      isEntrypoint: boolean;
    }
    const extractedReactFiles: ExtractedFile[] = [];
    if (isReactStack) {
      // Helper: classify file extension → language
      const classifyLang = (filePath: string) => {
        const ext = filePath.split(".").pop()?.toLowerCase() ?? "txt";
        return ext === "tsx" || ext === "ts"
          ? "typescript"
          : ext === "jsx" || ext === "js"
            ? "javascript"
            : ext === "css"
              ? "css"
              : ext === "json"
                ? "json"
                : "text";
      };

      // Primary pattern: FILE: path\n```lang\ncontent\n```
      const primaryRegex = /FILE:\s*([^\n]+)\n```[a-z]*\n([\s\S]*?)\n```/g;
      // Fallback 1: ### path\n```lang\ncontent\n```
      const fallback1Regex =
        /###\s+([\w./\-]+\.[a-z]+)\n```[a-z]*\n([\s\S]*?)\n```/g;
      // Fallback 2: **path**\n```lang\ncontent\n``` or `path`\n```lang\ncontent\n```
      const fallback2Regex =
        /(?:\*\*|`)([a-z][\w./\-]+\.[a-z]+)(?:\*\*|`)\s*\n```[a-z]*\n([\s\S]*?)\n```/g;

      const seenPaths = new Set<string>();
      const VALID_EXTENSIONS = /\.(tsx?|jsx?|css|html|json|md|env|gitignore|svg|mjs|cjs)$/;

      const addFile = (rawPath: string, content: string) => {
        const filePath = rawPath.trim();
        if (seenPaths.has(filePath)) return;
        if (!VALID_EXTENSIONS.test(filePath)) return; // skip false positives
        seenPaths.add(filePath);
        extractedReactFiles.push({
          path: filePath,
          content: content.replace(/\r\n/g, "\n"),
          language: classifyLang(filePath),
          isEntrypoint:
            filePath === "src/main.tsx" ||
            filePath === "src/index.tsx" ||
            filePath === "main.tsx",
        });
      };

      let match;
      while ((match = primaryRegex.exec(fullResponse)) !== null) {
        addFile(match[1], match[2]);
      }

      // Only use fallbacks if primary parser found nothing
      if (extractedReactFiles.length === 0) {
        while ((match = fallback1Regex.exec(fullResponse)) !== null)
          addFile(match[1], match[2]);
      }
      if (extractedReactFiles.length === 0) {
        while ((match = fallback2Regex.exec(fullResponse)) !== null)
          addFile(match[1], match[2]);
      }
    }

    // ── Save AI response to DB ──
    await db.insert(projectMessagesTable).values({
      projectId: params.id,
      role: "assistant",
      content: fullResponse,
    });

    // ── Extract & save DNA with retry (fire-and-forget, never blocks response) ──
    withRetry(() => extractAndSaveDNA(params.id, body.content, fullResponse, currentMode, detectedIntent.intent)).catch(
      (err) => logger.warn({ err, projectId: params.id }, "[Memory] DNA extraction failed"),
    );

    // ── Extract and save memory chunks (fire-and-forget) ─────────────────
    extractAndSaveMemoryChunks(
      params.id,
      body.content,
      fullResponse,
      rawChunks,
      detectedIntent.intent,
    ).catch((err) => logger.warn({ err, projectId: params.id }, "[Memory] Chunk extraction failed"));

    // ── Issue 19: Save to prompt_cache (fire-and-forget, only text responses) ──
    if (fullResponse.length < 50_000) {
      db.insert(promptCacheTable)
        .values({ hash: cacheKey, response: fullResponse, mode: currentMode })
        .onConflictDoNothing()
        .catch(() => {});
    }

    // ── Issue 17: Update user DNA from this interaction ───────────────────
    if (project.userId) {
      const stackSignal = project.stack ?? "html";
      const skillSignal =
        body.content.toLowerCase().includes("api") ||
        body.content.toLowerCase().includes("backend")
          ? "intermediate"
          : undefined;
      db.insert(userDnaTable)
        .values({
          userId: project.userId,
          preferredStack: stackSignal,
          ...(skillSignal ? { skillLevel: skillSignal } : {}),
          updatedAt: new Date(),
        })
        .onConflictDoUpdate({
          target: userDnaTable.userId,
          set: {
            preferredStack: stackSignal,
            ...(skillSignal ? { skillLevel: skillSignal } : {}),
            updatedAt: new Date(),
          },
        })
        .catch(() => {});
    }

    // ── Track usage + telemetry ──
    try {
      const finalMsg = await stream.finalMessage();
      const latencyMs = getLatencyMs();
      await recordAiCall({
        projectId: params.id,
        userId: req.user?.id ?? null,
        type: "ai_message",
        model: "claude-sonnet-4-5",
        inputTokens: finalMsg.usage?.input_tokens ?? 0,
        outputTokens: finalMsg.usage?.output_tokens ?? 0,
        latencyMs,
        promptVersion: PROMPT_VERSION,
        intentType: detectedIntent.intent,
      });
    } catch {
      /* non-critical */
    }

    // ── Update project preview & skill score ──
    const allMessages = await db
      .select()
      .from(projectMessagesTable)
      .where(eq(projectMessagesTable.projectId, params.id));

    const newSkillScore = calculateSkillScore(allMessages);

    const updateData: Record<string, unknown> = {
      updatedAt: new Date(),
      skillScore: newSkillScore,
    };

    // Validate HTML before saving — rejects truncated, empty, or structurally broken output
    const isHtmlUsable = (h: string | null | undefined): h is string => {
      if (!h || h.length < 800) return false;
      const lower = h.toLowerCase();
      // Must have proper document structure
      if (!lower.includes("</html>")) return false;
      if (!lower.includes("<body") && !lower.includes("<html")) return false;
      // Closing </html> should be near the end (not truncated mid-document)
      const closeIdx = lower.lastIndexOf("</html>");
      if (closeIdx < h.length * 0.4) return false;
      return true;
    };

    if (isHtmlUsable(extractedHtml)) {
      updateData.previewHtml = autoCdnInject(extractedHtml);
    }

    // ── Compute change summary before transaction (used for snapshot + SSE) ──
    const isPatchForSummary =
      !isFirstMessage &&
      (detectedIntent.intent === "fix" || detectedIntent.intent === "edit");
    const changeSummary =
      extractedHtml
        ? computeChangeSummary(
            project.previewHtml,
            extractedHtml,
            isPatchForSummary,
            extractedReactFiles.length > 0
              ? extractedReactFiles.map((f) => f.path)
              : undefined,
          )
        : undefined;

    // ── Atomic DB write: previewHtml + project_files + snapshot ────────────
    await db.transaction(async (tx) => {
      // ── Sync HTML to project_files as index.html ──
      if (isHtmlUsable(extractedHtml)) {
        const html = autoCdnInject(extractedHtml);
        await tx
          .insert(projectFilesTable)
          .values({
            projectId: params.id,
            path: "index.html",
            content: html,
            language: "html",
            isEntrypoint: true,
          })
          .onConflictDoUpdate({
            target: [projectFilesTable.projectId, projectFilesTable.path],
            set: { content: html, updatedAt: new Date() },
          });
      }

      // ── Sync React multi-file manifest to project_files ──
      if (extractedReactFiles.length > 0) {
        for (const f of extractedReactFiles) {
          await tx
            .insert(projectFilesTable)
            .values({
              projectId: params.id,
              path: f.path,
              content: f.content,
              language: f.language,
              isEntrypoint: f.isEntrypoint,
            })
            .onConflictDoUpdate({
              target: [projectFilesTable.projectId, projectFilesTable.path],
              set: {
                content: f.content,
                language: f.language,
                isEntrypoint: f.isEntrypoint,
                updatedAt: new Date(),
              },
            });
        }
        // Invalidate bundle cache so next /bundle request rebuilds
        invalidateBundleCache(params.id);
        // Signal that bundle needs refresh
        updateData.previewHtml = null; // React projects don't use previewHtml
      }

      // ── Save snapshot after AI generation (only valid HTML) ──
      if (isHtmlUsable(extractedHtml)) {
        const msgCount = allMessages.filter((m) => m.role === "user").length;
        const label = `גרסה ${msgCount}`;
        const snapshotHtml = autoCdnInject(extractedHtml);
        await tx.insert(projectSnapshotsTable).values({
          projectId: params.id,
          html: snapshotHtml,
          label,
          diffStats: (changeSummary ?? null) as unknown,
        });
        // Keep at most 30 snapshots per project
        const old = await tx
          .select({ id: projectSnapshotsTable.id })
          .from(projectSnapshotsTable)
          .where(eq(projectSnapshotsTable.projectId, params.id))
          .orderBy(desc(projectSnapshotsTable.createdAt))
          .offset(30);
        if (old.length > 0) {
          for (const o of old) {
            await tx
              .delete(projectSnapshotsTable)
              .where(eq(projectSnapshotsTable.id, o.id));
          }
        }
      }

      // ── Update main project record (inside transaction for atomicity) ──
      await tx
        .update(projectsTable)
        .set(updateData)
        .where(eq(projectsTable.id, params.id));
    });

    // ── Command 3: Improved Grow-With-Me ────────────────────────────────────
    let growWithMeSuggestion: string | null = null;
    const lowerUserMsg = body.content.toLowerCase();

    // 48-hour cooldown check
    const lastSuggestion = projectDna?.lastGrowSuggestionAt;
    const cooldownOk =
      !lastSuggestion ||
      Date.now() - new Date(lastSuggestion).getTime() > 48 * 60 * 60 * 1000;

    if (cooldownOk) {
      // Count messages from last 7 days (= session activity)
      const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
      const recentMessages = allMessages.filter(
        (m) => m.role === "user" && new Date(m.createdAt ?? 0) >= weekAgo,
      );
      const sessionCount = Math.ceil(recentMessages.length / 3); // 3 msgs ≈ 1 session

      // Collect signals from last 3 user messages for pattern detection
      const last3UserMsgs = allMessages
        .filter((m) => m.role === "user")
        .slice(-3)
        .map((m) => m.content.toLowerCase())
        .join(" ");

      // Signal groups
      const builderSignals = [
        "api",
        "database",
        "react",
        "component",
        "deploy",
        "backend",
        "frontend",
        "hook",
        "typescript",
        "github",
        "ci/cd",
        "docker",
      ];
      const developerSignals = [
        "typescript",
        "testing",
        "unit test",
        "ci/cd",
        "docker",
        "kubernetes",
        "microservice",
        "performance",
        "benchmark",
        "algorithm",
      ];
      const makerSignals = [
        "כיף",
        "לעצמי",
        "אישי",
        "for fun",
        "hobby",
        "game",
        "משחק",
        "three.js",
        "canvas",
        "animation",
        "creative",
      ];
      const entrepreneurSignals = [
        "לקוחות",
        "מכירות",
        "עסק",
        "תשלום",
        "הכנסה",
        "customers",
        "revenue",
        "business",
        "sell",
        "payment",
        "pricing",
        "saas",
      ];

      const countSignals = (signals: string[], text: string) =>
        signals.filter((s) => text.includes(s)).length;

      if (currentMode === "entrepreneur") {
        const techCount = countSignals(builderSignals, last3UserMsgs);
        const funCount = countSignals(makerSignals, last3UserMsgs);
        if (techCount >= 3 && newSkillScore >= 30 && sessionCount >= 2) {
          growWithMeSuggestion = "builder";
        } else if (funCount >= 2) {
          growWithMeSuggestion = "maker";
        }
      } else if (currentMode === "builder") {
        const devCount = countSignals(developerSignals, last3UserMsgs);
        if (devCount >= 3 && newSkillScore >= 70) {
          growWithMeSuggestion = "developer";
        } else if (countSignals(entrepreneurSignals, last3UserMsgs) >= 2) {
          growWithMeSuggestion = "entrepreneur";
        }
      } else if (currentMode === "developer") {
        // Reverse path: developer → entrepreneur when business signals appear
        const bizCount = countSignals(entrepreneurSignals, last3UserMsgs);
        if (bizCount >= 3) {
          growWithMeSuggestion = "entrepreneur";
        }
      } else if (currentMode === "maker") {
        const shareDeploySignals = [
          "שתף",
          "חברים",
          "domain",
          "deploy",
          "public",
          "share",
          "publish",
          "host",
        ];
        const shareCount = countSignals(shareDeploySignals, lowerUserMsg);
        const bizCount = countSignals(entrepreneurSignals, last3UserMsgs);
        if (shareCount >= 1 && sessionCount >= 2) {
          growWithMeSuggestion = "builder";
        } else if (bizCount >= 2) {
          growWithMeSuggestion = "entrepreneur";
        }
      }

      // Update cooldown + count in DNA if we're suggesting
      if (growWithMeSuggestion) {
        const currentCount = projectDna?.growSuggestionCount ?? 0;
        db.update(projectDnaTable)
          .set({
            lastGrowSuggestionAt: new Date(),
            growSuggestionCount: currentCount + 1,
            updatedAt: new Date(),
          })
          .where(eq(projectDnaTable.projectId, params.id))
          .catch(() => {});
      }
    }

    // Broadcast project update to collab viewers
    const hasUpdate = !!extractedHtml || extractedReactFiles.length > 0;
    if (hasUpdate) {
      broadcastProjectUpdate(String(params.id), { previewUpdated: true });
    }

    // ── Contextual Suggestions — detect what the project needs ───────────
    const codeForSuggestions = extractedHtml || fullResponse;
    const contextSuggestions = codeForSuggestions
      ? detectContextualSuggestions(
          codeForSuggestions,
          body.integrations as Record<string, string> | undefined,
        )
      : [];
    if (contextSuggestions.length > 0) {
      sendEvent({ type: "suggestions", suggestions: contextSuggestions });
    }

    // ── Issue 67: Auto-trigger QA after code generation ──────────────────
    if (hasUpdate && extractedHtml) {
      setImmediate(async () => {
        try {
          const code = extractedHtml.slice(0, 8000);
          const msg = await anthropic.messages.create({
            model: "claude-haiku-4-5-20251001",
            max_tokens: 800,
            messages: [
              {
                role: "user",
                content: `Analyze this HTML app and return a JSON object with: {"quality_score": number (0-100), "critical_issues": string[], "auto_fix_suggestions": [{"issue":string,"fix":string}]}. Code:\n${code}`,
              },
            ],
            system:
              "You are a QA engineer. Return only valid JSON, no explanation.",
          });
          const text =
            msg.content[0].type === "text" ? msg.content[0].text : "{}";
          const qa = JSON.parse(text.match(/\{[\s\S]*\}/)?.[0] ?? "{}");
          if (qa.quality_score !== undefined) {
            const coveragePct: number = Number(qa.quality_score) || 0;
            await db
              .insert(qaTestResultsTable)
              .values({
                projectId: params.id,
                testSuite: { auto_triggered: true, ...qa },
                coveragePercent: coveragePct,
                autoFixSuggestions: qa.auto_fix_suggestions ?? [],
                passed: coveragePct >= 70 ? 1 : 0,
                failed: coveragePct < 70 ? 1 : 0,
              })
              .catch(() => {});
          }
        } catch {
          /* non-critical, fire-and-forget */
        }
      });
    }

    sendEvent({
      done: true,
      previewUpdated: hasUpdate,
      filesUpdated:
        extractedReactFiles.length > 0
          ? extractedReactFiles.map((f) => f.path)
          : undefined,
      detectedMode: isFirstMessage ? currentMode : undefined,
      skillScore: newSkillScore,
      growWithMeSuggestion,
      changeSummary,
    });
  } catch (err) {
    console.error("[AI Stream Error]", err);
    sendEvent({ error: "AI generation failed. Please try again." });
  } finally {
    clearInterval(heartbeatInterval);
    res.end();
  }
});

export default router;
