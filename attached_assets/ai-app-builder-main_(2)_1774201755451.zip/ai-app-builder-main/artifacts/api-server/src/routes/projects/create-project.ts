import { Router } from "express";
import { db, projectsTable } from "@workspace/db";
import { CreateProjectBody } from "@workspace/api-zod";

const router = Router();

router.post("/", async (req, res) => {
  const body = CreateProjectBody.parse(req.body);
  const stack = (req.body as { stack?: string }).stack ?? "html";
  const userId = req.user?.id;
  const [project] = await db
    .insert(projectsTable)
    .values({
      title: body.title,
      description: body.description,
      type: body.type,
      stack,
      userMode: body.userMode ?? "entrepreneur",
      userId: userId ?? undefined,
    })
    .returning();
  res.status(201).json(project);
});

export default router;
