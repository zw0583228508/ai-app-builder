import { Router } from "express";
import { eq, or } from "drizzle-orm";
import { randomBytes } from "node:crypto";
import { db, projectsTable, projectFilesTable } from "@workspace/db";
import { GetProjectParams } from "@workspace/api-zod";

const router = Router({ mergeParams: true });

// ── Share ─────────────────────────────────────────────────────
router.post("/:id/share", async (req, res) => {
  const params = GetProjectParams.parse(req.params);
  const userId = req.user?.id;
  const project = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, params.id))
    .then((r) => r[0]);
  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }
  if (userId && project.userId && project.userId !== userId) {
    res.status(403).json({ error: "Not authorized" });
    return;
  }

  const isReactProject =
    project.stack === "react" || project.stack === "nextjs";
  if (!project.previewHtml && !isReactProject) {
    const hasFiles = await db
      .select({ id: projectFilesTable.projectId })
      .from(projectFilesTable)
      .where(eq(projectFilesTable.projectId, params.id))
      .limit(1)
      .then((r) => r.length > 0);
    if (!hasFiles) {
      res.status(400).json({ error: "No preview to share yet" });
      return;
    }
  }

  let token = project.shareToken;
  if (!token) {
    token = randomBytes(16).toString("hex");
    await db
      .update(projectsTable)
      .set({ shareToken: token })
      .where(eq(projectsTable.id, params.id));
  }
  res.json({ shareToken: token, customSlug: project.customSlug || null });
});

// ── Custom Slug ───────────────────────────────────────────────
router.patch("/:id/custom-slug", async (req, res) => {
  const params = GetProjectParams.parse(req.params);
  const { slug } = req.body as { slug: string };
  if (!slug || typeof slug !== "string") {
    res.status(400).json({ error: "slug required" });
    return;
  }
  const clean = slug
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9-]/g, "-")
    .replace(/-+/g, "-")
    .replace(/^-|-$/g, "")
    .slice(0, 50);
  if (!clean || clean.length < 3) {
    res.status(400).json({
      error: "Slug must be at least 3 characters (a-z, 0-9, hyphens)",
    });
    return;
  }

  const existing = await db
    .select({ id: projectsTable.id })
    .from(projectsTable)
    .where(eq(projectsTable.customSlug, clean))
    .then((r) => r[0]);
  if (existing && existing.id !== params.id) {
    res.status(409).json({ error: "כתובת זו כבר תפוסה" });
    return;
  }

  const project = await db
    .select()
    .from(projectsTable)
    .where(eq(projectsTable.id, params.id))
    .then((r) => r[0]);
  if (!project) {
    res.status(404).json({ error: "Project not found" });
    return;
  }
  let token = project.shareToken;
  if (!token) {
    token = randomBytes(16).toString("hex");
  }
  await db
    .update(projectsTable)
    .set({ customSlug: clean, shareToken: token })
    .where(eq(projectsTable.id, params.id));
  res.json({ customSlug: clean, shareToken: token });
});

// Fork route moved to fork.ts (Phase 3 modularization)

// ── Public share view ─────────────────────────────────────────
router.get("/share/:token", async (req, res) => {
  const { token } = req.params;
  const project = await db
    .select()
    .from(projectsTable)
    .where(
      or(
        eq(projectsTable.shareToken, token),
        eq(projectsTable.customSlug, token),
      ),
    )
    .then((r) => r[0]);
  if (!project) {
    res.status(404).send("<h1>Not found</h1>");
    return;
  }

  if (project.previewHtml) {
    res.setHeader("Content-Type", "text/html");
    res.send(project.previewHtml);
    return;
  }

  const isReactProject =
    project.stack === "react" || project.stack === "nextjs";
  if (isReactProject) {
    res.setHeader("Content-Type", "text/html");
    res.send(`<!DOCTYPE html><html><head><meta charset="UTF-8">
<meta http-equiv="refresh" content="0; url=/api/projects/${project.id}/bundle">
<title>Loading...</title></head>
<body style="background:#0f172a;color:#94a3b8;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;margin:0">
<p>טוען אפליקציה...</p></body></html>`);
    return;
  }

  res.status(404).send("<h1>Not found</h1>");
});

export default router;
