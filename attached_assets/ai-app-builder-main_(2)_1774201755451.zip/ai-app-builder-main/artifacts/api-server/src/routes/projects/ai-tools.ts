import { Router } from "express";

const router = Router({ mergeParams: true });

// Routes moved to dedicated modules (Phase 3 modularization):
//   enhance-prompt → prompt-enhance.ts
//   ai-review      → review.ts

export default router;
