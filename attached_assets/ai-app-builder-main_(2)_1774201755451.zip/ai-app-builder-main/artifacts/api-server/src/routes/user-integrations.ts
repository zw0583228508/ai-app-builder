import { Router, type IRouter, type Request, type Response } from "express";
import { db, userDnaTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { getSession } from "../lib/auth";

const router: IRouter = Router();

async function getUserId(req: Request): Promise<string | null> {
  const sid =
    req.cookies?.sid ?? req.headers.cookie?.match(/(?:^|;\s*)sid=([^;]+)/)?.[1];
  if (!sid) return null;
  const session = await getSession(sid).catch(() => null);
  return session?.user?.id ?? null;
}

// GET /api/user/integrations — fetch server-stored integration keys
router.get("/user/integrations", async (req: Request, res: Response) => {
  const userId = await getUserId(req);
  if (!userId) {
    res.status(401).json({ error: "לא מחובר" });
    return;
  }

  const [row] = await db
    .select({ integrations: userDnaTable.integrations })
    .from(userDnaTable)
    .where(eq(userDnaTable.userId, userId));

  res.json({
    integrations: (row?.integrations as Record<string, string>) ?? {},
  });
});

// PUT /api/user/integrations — save integration keys server-side
router.put("/user/integrations", async (req: Request, res: Response) => {
  const userId = await getUserId(req);
  if (!userId) {
    res.status(401).json({ error: "לא מחובר" });
    return;
  }

  const updates = req.body as Record<string, string>;
  if (typeof updates !== "object" || Array.isArray(updates)) {
    res.status(400).json({ error: "נתונים לא תקינים" });
    return;
  }

  // Sanitize: only allow string values, remove any non-string entries
  const sanitized: Record<string, string> = {};
  for (const [k, v] of Object.entries(updates)) {
    if (typeof v === "string") sanitized[k] = v;
  }

  // Upsert into user_dna
  await db
    .insert(userDnaTable)
    .values({ userId, integrations: sanitized, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: userDnaTable.userId,
      set: { integrations: sanitized, updatedAt: new Date() },
    });

  res.json({ ok: true });
});

export default router;
