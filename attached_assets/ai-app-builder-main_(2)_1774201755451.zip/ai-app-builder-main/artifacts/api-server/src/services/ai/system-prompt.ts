import type { IntegrationKeys } from "../types";
import {
  HEBREW_LANGUAGE_INSTRUCTION,
  ENTREPRENEUR_SYSTEM_PROMPT,
  BUILDER_SYSTEM_PROMPT,
  DEVELOPER_SYSTEM_PROMPT,
  MAKER_SYSTEM_PROMPT,
  REACT_STACK_RULES,
  VUE_STACK_RULES,
  SVELTE_STACK_RULES,
  DJANGO_STACK_RULES,
  SHARED_LIBRARIES,
} from "./prompts/index";

// Intents that don't create new code — no need for CDN library list.
const SKIP_LIBRARIES_INTENTS = new Set(["fix", "edit", "inspect"]);

export function getSystemPrompt(
  mode: string,
  integrations?: IntegrationKeys,
  projectType?: string,
  stack?: string,
  intent?: string,
): string {
  let base: string;

  if (stack === "react" || stack === "nextjs") {
    base = REACT_STACK_RULES;
  } else if (stack === "vue") {
    base = VUE_STACK_RULES;
  } else if (stack === "svelte") {
    base = SVELTE_STACK_RULES;
  } else if (stack === "django") {
    base = DJANGO_STACK_RULES;
  } else {
    switch (mode) {
      case "developer":
        base = DEVELOPER_SYSTEM_PROMPT;
        break;
      case "builder":
        base = BUILDER_SYSTEM_PROMPT;
        break;
      case "maker":
        base = MAKER_SYSTEM_PROMPT;
        break;
      case "entrepreneur":
      default:
        base = ENTREPRENEUR_SYSTEM_PROMPT;
    }
  }

  // Performance optimization: strip CDN library list for edit/fix/inspect intents
  // (~500 tokens saved per request — SHARED_LIBRARIES is not needed for code edits).
  if (intent && SKIP_LIBRARIES_INTENTS.has(intent)) {
    base = base.replace(SHARED_LIBRARIES, "");
  }

  if (projectType === "mobile") {
    base += `

══════════════════════════════════════════════════════════════
MOBILE APP MODE — BUILD A NATIVE-FEELING MOBILE EXPERIENCE
══════════════════════════════════════════════════════════════
The user wants a MOBILE APPLICATION. Build it as a Progressive Web App (PWA) that
feels like a real native mobile app. Follow these rules strictly:

LAYOUT & DESIGN:
• Maximum width: 390px centered (iPhone 14 Pro size), rest is background
• Use a fixed bottom navigation bar (like native apps: 4-5 icons)
• Header is fixed at top with safe-area padding
• All tap targets ≥ 44px (iOS Human Interface Guidelines)
• Use touch-friendly gestures: swipe hints, large buttons
• Smooth transitions between "screens" using CSS transitions (no page reloads)

VISUAL STYLE:
• Follow iOS/Android design patterns: cards, sheets, modals sliding up
• Use CSS custom properties for theming (support dark/light)
• Bottom sheets for secondary content (slide up from bottom)
• Haptic-style micro-animations on button tap (scale 0.95)
• Safe area insets: padding-bottom: env(safe-area-inset-bottom)

NAVIGATION:
• Build a proper SPA with multiple "screens" that swap via JS
• No browser back button needed — use in-app back arrows
• Tab bar at bottom with active state indicators

PERFORMANCE:
• Use CSS animations (not JS) for transitions
• Lazy load content as needed
• Skeleton loaders for async content

PWA MANIFEST (include inline in HTML):
• Add <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
• Add <meta name="mobile-web-app-capable" content="yes">
• Add <meta name="apple-mobile-web-app-capable" content="yes">

REMEMBER: This should look indistinguishable from a real iOS/Android app!
`;
  }

  let integrationBlock = "";

  if (integrations) {
    const parts: string[] = [];

    if (integrations.supabaseUrl && integrations.supabaseAnonKey) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS SUPABASE CONNECTED — USE IT FOR DATABASE FEATURES
══════════════════════════════════════════════════════════════
The user has a live Supabase project. When building apps that need data persistence,
authentication, or storage — use Supabase directly. Do NOT use localStorage as a
database replacement when Supabase is available.

Supabase Project URL: ${integrations.supabaseUrl}
Supabase Anon Key: ${integrations.supabaseAnonKey}

USE IN CODE:
<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
const { createClient } = supabase;
const sb = createClient('${integrations.supabaseUrl}', '${integrations.supabaseAnonKey}');

SUPABASE PATTERNS:
• Auth: sb.auth.signInWithOAuth({ provider: 'google' }) or sb.auth.signInWithPassword({email, password})
• Read data: const { data } = await sb.from('table_name').select('*')
• Insert: await sb.from('table_name').insert({ field: value })
• Update: await sb.from('table_name').update({ field: value }).eq('id', id)
• Delete: await sb.from('table_name').delete().eq('id', id)
• Real-time: sb.channel('room').on('postgres_changes', ...).subscribe()
• Storage: sb.storage.from('bucket').upload('path', file)

IMPORTANT: Always handle RLS (Row Level Security) — mention to the user that they need to
set up appropriate policies in Supabase Dashboard if data isn't loading.
`);
    }

    if (integrations.openaiKey) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS OPENAI API KEY — USE IT FOR AI FEATURES
══════════════════════════════════════════════════════════════
OpenAI API Key: ${integrations.openaiKey}
USE IN CODE:
const response = await fetch('https://api.openai.com/v1/chat/completions', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ${integrations.openaiKey}' },
  body: JSON.stringify({ model: 'gpt-4o-mini', messages: [{ role: 'user', content: userMessage }], max_tokens: 1000 })
});
const data = await response.json();
const reply = data.choices[0].message.content;
`);
    }

    if (integrations.anthropicKey) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS ANTHROPIC (CLAUDE) API KEY
══════════════════════════════════════════════════════════════
Anthropic API Key: ${integrations.anthropicKey}
USE IN CODE:
const response = await fetch('https://api.anthropic.com/v1/messages', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', 'x-api-key': '${integrations.anthropicKey}', 'anthropic-version': '2023-06-01' },
  body: JSON.stringify({ model: 'claude-3-haiku-20240307', max_tokens: 1024, messages: [{ role: 'user', content: userMessage }] })
});
const data = await response.json();
const reply = data.content[0].text;
`);
    }

    if (integrations.groqKey) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS GROQ API KEY — ULTRA-FAST INFERENCE
══════════════════════════════════════════════════════════════
Groq API Key: ${integrations.groqKey}
USE IN CODE (OpenAI-compatible):
const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ${integrations.groqKey}' },
  body: JSON.stringify({ model: 'llama3-8b-8192', messages: [{ role: 'user', content: userMessage }] })
});
const data = await response.json();
const reply = data.choices[0].message.content;
`);
    }

    if (integrations.huggingfaceToken) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS HUGGING FACE TOKEN — AI MODELS
══════════════════════════════════════════════════════════════
Hugging Face Token: ${integrations.huggingfaceToken}
USE IN CODE (Inference API):
const response = await fetch('https://api-inference.huggingface.co/models/MODEL_NAME', {
  method: 'POST',
  headers: { 'Authorization': 'Bearer ${integrations.huggingfaceToken}', 'Content-Type': 'application/json' },
  body: JSON.stringify({ inputs: userInput })
});
const result = await response.json();
Common models: mistralai/Mistral-7B-v0.1 (text), stabilityai/stable-diffusion-xl-base-1.0 (images)
`);
    }

    if (integrations.replicateToken) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS REPLICATE TOKEN — RUN AI MODELS IN CLOUD
══════════════════════════════════════════════════════════════
Replicate API Token: ${integrations.replicateToken}
USE IN CODE: Use via server-side proxy (never expose token client-side directly).
Backend pattern: POST https://api.replicate.com/v1/models/{owner}/{name}/predictions
Authorization: Token ${integrations.replicateToken}
`);
    }

    if (integrations.firebaseApiKey && integrations.firebaseProjectId) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS FIREBASE — USE FOR DATABASE / AUTH / STORAGE
══════════════════════════════════════════════════════════════
Firebase API Key: ${integrations.firebaseApiKey}
Firebase Project ID: ${integrations.firebaseProjectId}
USE IN CODE:
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore-compat.js"></script>
<script src="https://www.gstatic.com/firebasejs/10.7.1/firebase-auth-compat.js"></script>
const app = firebase.initializeApp({ apiKey: '${integrations.firebaseApiKey}', authDomain: '${integrations.firebaseProjectId}.firebaseapp.com', projectId: '${integrations.firebaseProjectId}' });
const db = firebase.firestore();
const auth = firebase.auth();
// Read: const snap = await db.collection('items').get();
// Write: await db.collection('items').add({ name: 'value' });
// Auth: await auth.signInWithPopup(new firebase.auth.GoogleAuthProvider());
`);
    }

    if (integrations.mongodbUri) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS MONGODB — USE FOR NOSQL DATABASE
══════════════════════════════════════════════════════════════
MongoDB URI: ${integrations.mongodbUri}
Note: MongoDB requires a server-side backend. Build an Express/Node.js API to interact with MongoDB, do NOT use the URI in client-side code. Create a /api/* proxy pattern or use Realm/Data API if available.
`);
    }

    if (integrations.upstashRedisUrl && integrations.upstashRedisToken) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS UPSTASH REDIS — USE FOR CACHING / RATE LIMITING
══════════════════════════════════════════════════════════════
Redis URL: ${integrations.upstashRedisUrl}
Redis Token: ${integrations.upstashRedisToken}
USE IN CODE (REST API — works client-side):
const setKey = async (key, value) => {
  await fetch(\`${integrations.upstashRedisUrl}/set/\${key}/\${encodeURIComponent(value)}\`, {
    headers: { Authorization: 'Bearer ${integrations.upstashRedisToken}' }
  });
};
const getKey = async (key) => {
  const res = await fetch(\`${integrations.upstashRedisUrl}/get/\${key}\`, {
    headers: { Authorization: 'Bearer ${integrations.upstashRedisToken}' }
  });
  const data = await res.json();
  return data.result;
};
`);
    }

    if (integrations.stripePublishableKey) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS STRIPE — USE FOR PAYMENTS
══════════════════════════════════════════════════════════════
Stripe Publishable Key: ${integrations.stripePublishableKey}
${integrations.stripeSecretKey ? `Stripe Secret Key: ${integrations.stripeSecretKey} (server-side only!)` : ""}
USE IN CODE (Stripe.js):
<script src="https://js.stripe.com/v3/"></script>
const stripe = Stripe('${integrations.stripePublishableKey}');
// For Checkout: redirect to Stripe-hosted page (requires backend for session creation)
// For Elements: const elements = stripe.elements(); — mount card element in a form
IMPORTANT: Never use the Secret Key in client-side code. Use it only in server-side code.
`);
    }

    if (integrations.paypalClientId) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS PAYPAL — USE FOR PAYMENTS
══════════════════════════════════════════════════════════════
PayPal Client ID: ${integrations.paypalClientId}
USE IN CODE:
<script src="https://www.paypal.com/sdk/js?client-id=${integrations.paypalClientId}&currency=USD"></script>
paypal.Buttons({
  createOrder: (data, actions) => actions.order.create({ purchase_units: [{ amount: { value: '10.00' } }] }),
  onApprove: (data, actions) => actions.order.capture().then(details => alert('Payment done by ' + details.payer.name.given_name))
}).render('#paypal-button-container');
`);
    }

    if (integrations.auth0Domain && integrations.auth0ClientId) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS AUTH0 — USE FOR AUTHENTICATION
══════════════════════════════════════════════════════════════
Auth0 Domain: ${integrations.auth0Domain}
Auth0 Client ID: ${integrations.auth0ClientId}
USE IN CODE:
<script src="https://cdn.auth0.com/js/auth0-spa-js/2.0/auth0-spa-js.production.js"></script>
const auth0Client = await auth0.createAuth0Client({ domain: '${integrations.auth0Domain}', clientId: '${integrations.auth0ClientId}', authorizationParams: { redirect_uri: window.location.origin } });
// Login: await auth0Client.loginWithRedirect();
// Get user: const user = await auth0Client.getUser();
// Logout: auth0Client.logout({ logoutParams: { returnTo: window.location.origin } });
`);
    }

    if (integrations.clerkPublishableKey) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS CLERK — USE FOR AUTHENTICATION
══════════════════════════════════════════════════════════════
Clerk Publishable Key: ${integrations.clerkPublishableKey}
USE IN CODE (ClerkJS):
<script async crossorigin="anonymous" data-clerk-publishable-key="${integrations.clerkPublishableKey}" src="https://cdn.jsdelivr.net/npm/@clerk/clerk-js@latest/dist/clerk.browser.js" type="text/javascript"></script>
// After load: await window.Clerk.load(); const user = Clerk.user;
// Sign in: Clerk.openSignIn(); // Sign up: Clerk.openSignUp();
`);
    }

    if (integrations.cloudinaryCloudName && integrations.cloudinaryApiKey) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS CLOUDINARY — USE FOR IMAGE/VIDEO UPLOADS
══════════════════════════════════════════════════════════════
Cloud Name: ${integrations.cloudinaryCloudName}
API Key: ${integrations.cloudinaryApiKey}
USE IN CODE (unsigned upload):
const uploadImage = async (file) => {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('upload_preset', 'ml_default');
  const res = await fetch('https://api.cloudinary.com/v1_1/${integrations.cloudinaryCloudName}/image/upload', { method: 'POST', body: formData });
  const data = await res.json();
  return data.secure_url;
};
// Transform: https://res.cloudinary.com/${integrations.cloudinaryCloudName}/image/upload/w_300,h_300,c_fill/PUBLIC_ID
`);
    }

    if (integrations.twilioAccountSid && integrations.twilioAuthToken) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS TWILIO — USE FOR SMS / VOICE
══════════════════════════════════════════════════════════════
Account SID: ${integrations.twilioAccountSid}
Auth Token: ${integrations.twilioAuthToken} (server-side only!)
NOTE: Twilio requires server-side calls. Build a backend endpoint to send SMS. Never expose Auth Token in client-side code.
Server-side: POST https://api.twilio.com/2010-04-01/Accounts/${integrations.twilioAccountSid}/Messages.json with Basic Auth.
`);
    }

    if (integrations.sendgridApiKey) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS SENDGRID — USE FOR EMAIL
══════════════════════════════════════════════════════════════
SendGrid API Key: ${integrations.sendgridApiKey} (server-side only!)
NOTE: Email sending requires server-side. Build a /api/send-email endpoint.
Server-side: POST https://api.sendgrid.com/v3/mail/send with Authorization: Bearer KEY
`);
    }

    if (integrations.resendApiKey) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS RESEND — USE FOR TRANSACTIONAL EMAIL
══════════════════════════════════════════════════════════════
Resend API Key: ${integrations.resendApiKey} (server-side only!)
NOTE: Email sending requires server-side. Build a /api/send-email endpoint.
Server-side: POST https://api.resend.com/emails — Body: { from, to, subject, html }
Authorization: Bearer ${integrations.resendApiKey}
`);
    }

    if (integrations.pusherKey && integrations.pusherCluster) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS PUSHER CHANNELS — USE FOR REAL-TIME FEATURES
══════════════════════════════════════════════════════════════
Pusher Key: ${integrations.pusherKey}
Pusher Cluster: ${integrations.pusherCluster}
${integrations.pusherAppId ? `App ID: ${integrations.pusherAppId}` : ""}
USE IN CODE (Pusher JS):
<script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
const pusher = new Pusher('${integrations.pusherKey}', { cluster: '${integrations.pusherCluster}' });
const channel = pusher.subscribe('my-channel');
channel.bind('my-event', (data) => console.log(data));
// Triggering events requires server-side Pusher SDK (never client-side for security).
`);
    }

    if (integrations.googleMapsApiKey) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS GOOGLE MAPS API KEY
══════════════════════════════════════════════════════════════
Google Maps API Key: ${integrations.googleMapsApiKey}
USE IN CODE:
<script src="https://maps.googleapis.com/maps/api/js?key=${integrations.googleMapsApiKey}&libraries=places"></script>
const map = new google.maps.Map(document.getElementById('map'), { zoom: 12, center: { lat: 32.0853, lng: 34.7818 } });
// Places autocomplete: const autocomplete = new google.maps.places.Autocomplete(inputEl);
// Geocoding: new google.maps.Geocoder().geocode({ address }, (results) => ...);
`);
    }

    if (integrations.mapboxToken) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS MAPBOX ACCESS TOKEN
══════════════════════════════════════════════════════════════
Mapbox Access Token: ${integrations.mapboxToken}
USE IN CODE:
<script src="https://api.mapbox.com/mapbox-gl-js/v3.0.0/mapbox-gl.js"></script>
<link href="https://api.mapbox.com/mapbox-gl-js/v3.0.0/mapbox-gl.css" rel="stylesheet" />
mapboxgl.accessToken = '${integrations.mapboxToken}';
const map = new mapboxgl.Map({ container: 'map', style: 'mapbox://styles/mapbox/dark-v11', center: [34.7818, 32.0853], zoom: 12 });
`);
    }

    if (integrations.algoliaAppId && integrations.algoliaApiKey) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS ALGOLIA — USE FOR INSTANT SEARCH
══════════════════════════════════════════════════════════════
App ID: ${integrations.algoliaAppId}
Search API Key: ${integrations.algoliaApiKey}
USE IN CODE:
<script src="https://cdn.jsdelivr.net/npm/algoliasearch@4/dist/algoliasearch-lite.umd.js"></script>
const client = algoliasearch('${integrations.algoliaAppId}', '${integrations.algoliaApiKey}');
const index = client.initIndex('INDEX_NAME');
const results = await index.search(query, { hitsPerPage: 10 });
// results.hits contains matching records
`);
    }

    if (integrations.slackBotToken) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS SLACK BOT TOKEN
══════════════════════════════════════════════════════════════
Slack Bot Token: ${integrations.slackBotToken} (server-side only!)
NOTE: Use server-side only. Send messages: POST https://slack.com/api/chat.postMessage
Body: { channel: '#general', text: 'Hello' } — Authorization: Bearer TOKEN
`);
    }

    if (integrations.discordBotToken) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS DISCORD BOT TOKEN
══════════════════════════════════════════════════════════════
Discord Bot Token: ${integrations.discordBotToken} (server-side only!)
NOTE: Use server-side only. Send messages: POST https://discord.com/api/v10/channels/CHANNEL_ID/messages
Body: { content: 'Hello' } — Authorization: Bot TOKEN
`);
    }

    if (integrations.twitterBearerToken) {
      parts.push(`
══════════════════════════════════════════════════════════════
USER HAS X (TWITTER) API BEARER TOKEN
══════════════════════════════════════════════════════════════
Bearer Token: ${integrations.twitterBearerToken}
USE IN CODE (read-only, v2 API):
const searchTweets = async (query) => {
  const res = await fetch(\`https://api.twitter.com/2/tweets/search/recent?query=\${encodeURIComponent(query)}&max_results=10\`, {
    headers: { Authorization: 'Bearer ${integrations.twitterBearerToken}' }
  });
  return (await res.json()).data;
};
`);
    }

    if (parts.length > 0) {
      integrationBlock = "\n" + parts.join("\n");
    }
  }

  return HEBREW_LANGUAGE_INSTRUCTION + "\n" + base + integrationBlock;
}
