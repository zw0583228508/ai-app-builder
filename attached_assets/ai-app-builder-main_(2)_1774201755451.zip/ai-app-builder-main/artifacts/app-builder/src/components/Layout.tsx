import { useState, useEffect } from "react";
import { Sidebar } from "./Sidebar";
import { CreateProjectModal } from "./CreateProjectModal";
import { WifiOff, Wifi } from "lucide-react";
import { cn } from "@/lib/utils";

const HE = "'Rubik', sans-serif";

function OfflineBanner() {
  const [online, setOnline] = useState(navigator.onLine);
  const [showReconnected, setShowReconnected] = useState(false);

  useEffect(() => {
    const handleOffline = () => setOnline(false);
    const handleOnline = () => {
      setOnline(true);
      setShowReconnected(true);
      setTimeout(() => setShowReconnected(false), 3000);
    };
    window.addEventListener("offline", handleOffline);
    window.addEventListener("online", handleOnline);
    return () => {
      window.removeEventListener("offline", handleOffline);
      window.removeEventListener("online", handleOnline);
    };
  }, []);

  if (online && !showReconnected) return null;

  return (
    <div
      className={cn(
        "fixed top-0 left-0 right-0 z-[9999] flex items-center justify-center gap-2 py-2 text-xs font-medium transition-all animate-in slide-in-from-top duration-300 shadow-lg",
        !online ? "bg-[#ef4444] text-white" : "bg-[#10b981] text-white"
      )}
      style={{ fontFamily: HE }}
    >
      {!online ? (
        <><WifiOff className="w-3.5 h-3.5" /><span>אין חיבור לאינטרנט — ההודעות שלך ישמרו ויישלחו כשהחיבור יחזור</span></>
      ) : (
        <><Wifi className="w-3.5 h-3.5" /><span>החיבור חזר ✓</span></>
      )}
    </div>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    const handle = () => setIsModalOpen(true);
    window.addEventListener("builder-new-project", handle);
    return () => window.removeEventListener("builder-new-project", handle);
  }, []);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setIsModalOpen(true);
      }
    };
    document.addEventListener("keydown", handleKey);
    return () => document.removeEventListener("keydown", handleKey);
  }, []);

  return (
    <div className="flex h-screen w-full overflow-hidden bg-[#0a0a0f] text-slate-300 font-sans">
      <OfflineBanner />
      <Sidebar onNewProject={() => setIsModalOpen(true)} />

      <main className="flex-1 relative min-w-0 h-full">
        {children}
      </main>

      <CreateProjectModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
      />
    </div>
  );
}