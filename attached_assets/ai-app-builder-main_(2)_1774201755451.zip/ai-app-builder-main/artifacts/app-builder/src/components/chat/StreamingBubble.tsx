import { Bot, CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";
import { AgentProgressPanel } from "./AgentProgressPanel";

const HE = "'Rubik', sans-serif";

interface PipelineStep {
  step: string;
  done?: boolean;
}

interface AgentStep {
  id: number;
  emoji: string;
  title: string;
  status: "pending" | "running" | "done";
}

interface FixLogEntry {
  fixed: boolean;
  issues: unknown[];
}

interface IntentInfo {
  emoji: string;
  label: string;
}

interface StreamingBubbleProps {
  streamedText: string;
  isGeneratingCode: boolean;
  codeLines: number;
  currentIntent: IntentInfo | null;
  pipelineMessage: string | null;
  pipelineSteps: PipelineStep[];
  agentPhase: string | null;
  agentSteps: AgentStep[];
  agentFixLog: FixLogEntry[];
  agentStepsCompleted: number | null;
}

export function StreamingBubble({
  streamedText,
  isGeneratingCode,
  codeLines,
  currentIntent,
  pipelineMessage,
  pipelineSteps,
  agentPhase,
  agentSteps,
  agentFixLog,
  agentStepsCompleted,
}: StreamingBubbleProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex gap-4 max-w-[90%]"
    >
      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center shrink-0 border border-primary/30 text-primary mt-1 shadow-sm shadow-primary/20">
        <Bot className="w-4 h-4" />
      </div>
      <div className="flex-1 overflow-hidden space-y-3">
        {/* Conversational text — streams in real time */}
        {streamedText && (
          <div className="text-sm leading-relaxed text-foreground/90 whitespace-pre-wrap">
            {streamedText}
            {!isGeneratingCode && (
              <span className="inline-block w-[3px] h-[1.1em] ml-0.5 bg-primary/80 rounded-sm animate-[blink_1s_ease-in-out_infinite] align-text-bottom" />
            )}
          </div>
        )}

        {/* Intent indicator — shown while streaming before text appears */}
        {currentIntent && !streamedText && !isGeneratingCode && (
          <div
            className="flex items-center gap-2 px-3 py-2 rounded-lg bg-indigo-500/10 border border-indigo-500/20 w-fit"
            style={{ fontFamily: HE }}
            dir="rtl"
          >
            <span className="text-sm">{currentIntent.emoji}</span>
            <span className="text-xs text-indigo-400">
              {currentIntent.label}
            </span>
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 animate-pulse shrink-0" />
          </div>
        )}

        {/* Code-generation progress bar */}
        {isGeneratingCode && (
          <div className="flex flex-col gap-1 w-full max-w-sm">
            <div className="h-1 w-full bg-white/[0.04] rounded-full overflow-hidden">
              <motion.div
                className="h-full bg-indigo-500"
                initial={{ width: "0%" }}
                animate={{ width: "100%" }}
                transition={{ duration: 2, ease: "linear", repeat: Infinity }}
              />
            </div>
            <div className="flex items-center justify-between mt-1 px-1">
              <span
                className="text-[10px] text-indigo-400 font-medium"
                style={{ fontFamily: HE }}
              >
                {currentIntent?.emoji} {currentIntent?.label || "כותב קוד"}...
              </span>
              <span
                className="text-[10px] text-slate-500"
                style={{ fontFamily: HE }}
              >
                {codeLines} שורות נכתבו
              </span>
            </div>
          </div>
        )}

        {/* Multi-Agent Pipeline status */}
        {pipelineMessage && !agentPhase && (
          <div className="space-y-2 pb-1 border-b border-amber-500/10">
            <div
              className="flex items-center gap-2 text-xs text-amber-400/80"
              style={{ fontFamily: HE }}
            >
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse shrink-0" />
              {pipelineMessage}
            </div>
            {pipelineSteps.length > 0 && (
              <div className="flex gap-1.5 flex-wrap">
                {[
                  { key: "architecture", label: "ארכיטקטורה", emoji: "🏗️" },
                  { key: "ui", label: "עיצוב", emoji: "🎨" },
                  { key: "security", label: "אבטחה", emoji: "🔒" },
                  { key: "performance", label: "ביצועים", emoji: "⚡" },
                ].map(({ key, label, emoji }) => {
                  const done = pipelineSteps.find((s) => s.step === key);
                  return (
                    <span
                      key={key}
                      className={`text-[10px] px-2 py-0.5 rounded-full border transition-all ${done ? "border-green-500/40 bg-green-500/10 text-green-400" : "border-slate-700 bg-slate-800/50 text-slate-500"}`}
                      style={{ fontFamily: HE }}
                    >
                      {done && <CheckCircle2 className="w-2.5 h-2.5 inline mr-1" />}
                      {emoji} {label}
                    </span>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* Agent Flow Progress */}
        <AgentProgressPanel
          agentPhase={agentPhase}
          agentSteps={agentSteps}
          agentFixLog={agentFixLog}
          agentStepsCompleted={agentStepsCompleted}
        />

        {/* Thinking indicator — before any content appears */}
        {!streamedText &&
          !isGeneratingCode &&
          !pipelineMessage &&
          !agentPhase &&
          agentSteps.length === 0 && (
            <div
              className="flex items-center gap-2 text-indigo-400 text-sm"
              style={{ fontFamily: HE }}
            >
              <div className="flex gap-1">
                <span
                  className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"
                  style={{ animationDelay: "0ms" }}
                />
                <span
                  className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"
                  style={{ animationDelay: "150ms" }}
                />
                <span
                  className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse"
                  style={{ animationDelay: "300ms" }}
                />
              </div>
            </div>
          )}
      </div>
    </motion.div>
  );
}
