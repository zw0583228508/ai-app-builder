import { Sparkles } from "lucide-react";
import { cn } from "@/lib/utils";

const HE = "'Rubik', sans-serif";

interface ModeIdea {
  icon: string;
  title: string;
  desc: string;
  prompt: string;
}

interface ModeConfig {
  icon: string;
  bgColor: string;
  welcomeTitle: string;
  welcomeSubtitle: string;
  quickStartLabel: string;
  ideas: ModeIdea[];
}

interface QuickIdeasGridProps {
  modeConfig: ModeConfig;
  onIdeaSelect: (prompt: string) => void;
}

export function QuickIdeasGrid({ modeConfig, onIdeaSelect }: QuickIdeasGridProps) {
  return (
    <div className="h-full flex flex-col max-w-4xl mx-auto pb-8">
      <div className="flex flex-col items-center justify-center text-center mt-6 mb-10 opacity-90">
        <div
          className={cn(
            "w-16 h-16 rounded-2xl flex items-center justify-center mb-5 shadow-lg text-3xl",
            modeConfig.bgColor,
          )}
        >
          {modeConfig.icon}
        </div>
        <h3
          className="text-2xl font-bold mb-2"
          style={{ fontFamily: HE }}
        >
          {modeConfig.welcomeTitle}
        </h3>
        <p
          className="text-muted-foreground text-sm max-w-md leading-relaxed"
          style={{ fontFamily: HE }}
        >
          {modeConfig.welcomeSubtitle}
        </p>
      </div>

      <div
        className="mb-4 flex items-center gap-2 text-sm font-medium text-foreground/80 px-2"
        style={{ fontFamily: HE }}
      >
        <Sparkles className="w-4 h-4 text-primary" />
        {modeConfig.quickStartLabel}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
        {modeConfig.ideas.map((idea, idx) => (
          <button
            key={idx}
            onClick={() => onIdeaSelect(idea.prompt)}
            className="text-right p-4 rounded-xl border border-white/[0.06] bg-[#16161f] hover:bg-white/[0.04] hover:border-indigo-500/30 transition-all flex flex-col gap-2 group"
          >
            <div className="text-2xl mb-1 group-hover:scale-110 transition-transform origin-bottom-right">
              {idea.icon}
            </div>
            <h4
              className="font-semibold text-sm text-slate-100"
              style={{ fontFamily: HE }}
            >
              {idea.title}
            </h4>
            <p
              className="text-xs text-slate-400 leading-relaxed"
              style={{ fontFamily: HE }}
            >
              {idea.desc}
            </p>
          </button>
        ))}
      </div>
    </div>
  );
}
