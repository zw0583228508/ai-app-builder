import { useState } from "react";
import {
  Bot,
  User,
  Code2,
  ChevronDown,
  ChevronUp,
  Copy,
  Check,
} from "lucide-react";
import { ProjectMessage } from "@workspace/api-client-react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { motion, AnimatePresence } from "framer-motion";
import { cn } from "@/lib/utils";

const HE = "'Rubik', sans-serif";

// ── Code fence languages that represent full output files ─────
const OUTPUT_FENCE_LANGS = ["html", "jsx", "tsx", "js", "ts", "css", "svelte", "vue", "py", "python"] as const;

// ── Strip patch-format markers from displayed text ────────────
function stripPatchMarkers(text: string): string {
  return text
    .replace(/<<<REPLACE>>>/g, "")
    .replace(/<<<END>>>/g, "")
    .replace(/<<<FILE:[^>]*>>>/g, "")
    .replace(/\[PATCH_APPLIED\]/g, "")
    .trim();
}

// ── Utility: extract code block from AI message ──────────────
export function extractCodeAndText(content: string): {
  text: string;
  code: string | null;
  lang: string | null;
} {
  // 1. Patch-applied marker — handle first, no code to show
  if (content.includes("[PATCH_APPLIED]")) {
    return {
      text: stripPatchMarkers(content.replace("[PATCH_APPLIED]", "")).trim(),
      code: "patch-applied",
      lang: null,
    };
  }

  // 2. Patch markers embedded in content — strip and return as patch
  if (content.includes("<<<REPLACE>>>") || content.includes("<<<FILE:")) {
    return {
      text: stripPatchMarkers(content),
      code: "patch-applied",
      lang: null,
    };
  }

  // 3. Markdown code fence: ```lang ... ``` (all output-relevant languages)
  for (const lang of OUTPUT_FENCE_LANGS) {
    const tag = `\`\`\`${lang}`;
    const fenceStart = content.indexOf(tag);
    if (fenceStart !== -1) {
      const afterTag = fenceStart + tag.length;
      // Find closing fence that starts at beginning of a line
      const closingMatch = content.slice(afterTag).search(/\n```\s*(\n|$)/);
      if (closingMatch !== -1) {
        const code = content.slice(afterTag, afterTag + closingMatch).trim();
        const closingEnd = afterTag + closingMatch + content.slice(afterTag + closingMatch).indexOf("\n```") + 4;
        const text = (content.slice(0, fenceStart) + content.slice(closingEnd)).trim();
        return { text: stripPatchMarkers(text), code, lang };
      } else {
        // Unclosed fence (streaming in progress) — still extract
        const code = content.slice(afterTag).trim();
        const text = content.slice(0, fenceStart).trim();
        return { text: stripPatchMarkers(text), code, lang };
      }
    }
  }

  // 4. Generic code fence ```  (no language tag)
  const genericFence = content.indexOf("```\n");
  if (genericFence !== -1) {
    const afterFence = genericFence + 4;
    const closingFence = content.indexOf("\n```", afterFence);
    if (closingFence !== -1) {
      const code = content.slice(afterFence, closingFence).trim();
      const text = (content.slice(0, genericFence) + content.slice(closingFence + 4)).trim();
      return { text: stripPatchMarkers(text), code, lang: null };
    }
  }

  // 5. Raw <!DOCTYPE html> or <html> block
  const htmlStart = content.search(/<!DOCTYPE html>|<html/i);
  if (htmlStart !== -1) {
    const code = content.slice(htmlStart).trim();
    const text = content.slice(0, htmlStart).trim();
    return { text: stripPatchMarkers(text), code, lang: "html" };
  }

  return { text: stripPatchMarkers(content), code: null, lang: null };
}

// ── Product spec types and utilities ─────────────────────────
interface ProductSpec {
  productName?: string;
  tagline?: string;
  targetAudience?: string;
  businessGoal?: string;
  coreFeatures?: string[];
  pages?: string[];
  userRoles?: string[];
  designStyle?: string;
  primaryColor?: string;
  techStack?: string;
  monetization?: string;
  integrations?: string[];
  contentLanguage?: string;
  priority?: string;
}

function parseProductSpec(content: string): ProductSpec | null {
  const match = content.match(/\[PRODUCT_SPEC\]([\s\S]*?)\[\/PRODUCT_SPEC\]/);
  if (!match) return null;
  try {
    return JSON.parse(match[1].trim()) as ProductSpec;
  } catch {
    return null;
  }
}

function stripSpecBlock(content: string): string {
  return content
    .replace(/\[PRODUCT_SPEC\][\s\S]*?\[\/PRODUCT_SPEC\]\n*/g, "")
    .trim();
}

function SpecBlock({
  icon,
  label,
  value,
}: {
  icon: string;
  label: string;
  value: string;
}) {
  return (
    <div
      className="rounded-xl border border-border/40 bg-background/40 p-2.5"
      style={{ fontFamily: HE }}
    >
      <p className="text-[10px] text-muted-foreground mb-0.5">
        {icon} {label}
      </p>
      <p className="text-[12px] text-foreground/90 font-medium leading-snug">
        {value}
      </p>
    </div>
  );
}

function ProductSpecCard({ spec }: { spec: ProductSpec }) {
  const color = spec.primaryColor ?? "#06b6d4";
  return (
    <div
      className="rounded-2xl border border-border/60 overflow-hidden bg-card/60 backdrop-blur-sm shadow-xl w-full"
      style={{ fontFamily: HE }}
    >
      {/* Header */}
      <div
        className="px-5 pt-5 pb-4 border-b border-border/40"
        style={{
          background: `linear-gradient(135deg, ${color}18, ${color}08)`,
        }}
      >
        <div className="flex items-start gap-3">
          <div
            className="w-10 h-10 rounded-xl flex items-center justify-center text-lg shrink-0 border"
            style={{ background: `${color}20`, borderColor: `${color}40` }}
          >
            📋
          </div>
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-base text-foreground leading-tight">
              {spec.productName ?? "מפרט המוצר"}
            </h3>
            {spec.tagline && (
              <p className="text-xs text-muted-foreground mt-0.5 leading-snug">
                {spec.tagline}
              </p>
            )}
          </div>
          {spec.primaryColor && (
            <div
              className="w-5 h-5 rounded-full border-2 border-white/20 shrink-0 mt-0.5"
              style={{ background: spec.primaryColor }}
              title={spec.primaryColor}
            />
          )}
        </div>
      </div>

      {/* Body grid */}
      <div className="p-4 grid gap-3">
        {/* Row 1: audience + goal */}
        <div className="grid grid-cols-2 gap-3">
          {spec.targetAudience && (
            <SpecBlock icon="👥" label="קהל יעד" value={spec.targetAudience} />
          )}
          {spec.businessGoal && (
            <SpecBlock icon="🎯" label="מטרה עסקית" value={spec.businessGoal} />
          )}
        </div>

        {/* Row 2: design + tech */}
        <div className="grid grid-cols-2 gap-3">
          {spec.designStyle && (
            <SpecBlock icon="🎨" label="סגנון עיצוב" value={spec.designStyle} />
          )}
          {spec.techStack && (
            <SpecBlock icon="⚙️" label="טכנולוגיה" value={spec.techStack} />
          )}
        </div>

        {/* Row 3: monetization + language */}
        {(spec.monetization || spec.contentLanguage) && (
          <div className="grid grid-cols-2 gap-3">
            {spec.monetization && (
              <SpecBlock
                icon="💳"
                label="מודל הכנסות"
                value={spec.monetization}
              />
            )}
            {spec.contentLanguage && (
              <SpecBlock
                icon="🌐"
                label="שפת תוכן"
                value={spec.contentLanguage}
              />
            )}
          </div>
        )}

        {/* Features */}
        {spec.coreFeatures && spec.coreFeatures.length > 0 && (
          <div className="rounded-xl border border-border/40 bg-background/40 p-3">
            <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide mb-2">
              ✨ פיצ'רים מרכזיים
            </p>
            <div className="flex flex-wrap gap-1.5">
              {spec.coreFeatures.map((f, i) => (
                <span
                  key={i}
                  className="text-[11px] px-2 py-0.5 rounded-full bg-primary/10 border border-primary/20 text-primary/90"
                >
                  {f}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Pages */}
        {spec.pages && spec.pages.length > 0 && (
          <div className="rounded-xl border border-border/40 bg-background/40 p-3">
            <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide mb-2">
              📄 דפים / מסכים
            </p>
            <div className="flex flex-wrap gap-1.5">
              {spec.pages.map((p, i) => (
                <span
                  key={i}
                  className="text-[11px] px-2 py-0.5 rounded-full bg-muted/60 border border-border/50 text-foreground/80"
                >
                  {p}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Integrations */}
        {spec.integrations &&
          spec.integrations.length > 0 &&
          spec.integrations[0] !== "None" &&
          spec.integrations[0] !== "אין" && (
            <div className="rounded-xl border border-border/40 bg-background/40 p-3">
              <p className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wide mb-2">
                🔌 אינטגרציות
              </p>
              <div className="flex flex-wrap gap-1.5">
                {spec.integrations.map((ig, i) => (
                  <span
                    key={i}
                    className="text-[11px] px-2 py-0.5 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400/90"
                  >
                    {ig}
                  </span>
                ))}
              </div>
            </div>
          )}
      </div>
    </div>
  );
}

export function MessageBubble({ message }: { message: ProjectMessage }) {
  const isUser = message.role === "user";
  const [showCode, setShowCode] = useState(false);
  const [copied, setCopied] = useState(false);

  const hasSpec = !isUser && message.content.includes("[PRODUCT_SPEC]");
  const parsedSpec = hasSpec ? parseProductSpec(message.content) : null;

  const rawContent = hasSpec
    ? stripSpecBlock(message.content)
    : message.content;
  const { text: displayContent, code: extractedCode, lang: codeLang } = isUser
    ? { text: message.content, code: null, lang: null }
    : extractCodeAndText(rawContent);

  const isPatch = extractedCode === "patch-applied";
  const hasCode = !!extractedCode;
  const hasViewableCode = hasCode && !isPatch;

  const handleCopy = () => {
    if (extractedCode && !isPatch) {
      navigator.clipboard.writeText(extractedCode);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className={cn(
        "flex gap-4 max-w-[92%]",
        isUser ? "mr-auto flex-row-reverse" : "ml-auto",
      )}
      dir="rtl"
    >
      <div
        className={cn(
          "w-8 h-8 rounded-full flex items-center justify-center shrink-0 border mt-1 shadow-sm",
          isUser
            ? "bg-[#16161f] text-slate-300 border-white/[0.08]"
            : "bg-indigo-500/10 text-indigo-400 border-indigo-500/20 shadow-indigo-500/10",
        )}
      >
        {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
      </div>

      <div
        className={cn(
          "flex flex-col gap-2 flex-1 min-w-0",
          isUser
            ? "px-5 py-3.5 rounded-2xl bg-[#1c1c28] border border-white/[0.04]"
            : "py-1",
        )}
      >
        {/* Product Spec Card — shown before text when spec is detected */}
        {parsedSpec && <ProductSpecCard spec={parsedSpec} />}

        {/* Conversational text — always shown */}
        {displayContent && (
          <div
            className={cn(
              "prose prose-invert max-w-none prose-sm leading-relaxed overflow-hidden",
              !isUser && hasCode && "border-l-2 border-indigo-500/40 pl-3 ml-1",
            )}
            dir="auto"
          >
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {displayContent}
            </ReactMarkdown>
          </div>
        )}

        {/* Code toggle — only for AI messages with HTML */}
        {hasCode && (
          <div className="mt-1">
            {/* Preview badge + toggle button */}
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-indigo-500/5 border border-indigo-500/20 text-xs flex-1">
                <span className="text-base">✅</span>
                <span
                  className="text-indigo-400 font-medium"
                  style={{ fontFamily: HE }}
                >
                  {isPatch ? "קוד עודכן" : "תצוגה מקדימה נוצרה"}
                </span>
                <span
                  className="text-slate-500 mr-auto text-[10px]"
                  style={{ fontFamily: HE }}
                >
                  ← מוצגת בצד ימין
                </span>
              </div>
              {hasViewableCode && (
                <button
                  onClick={() => setShowCode((v) => !v)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#16161f] border border-white/[0.06] text-xs text-slate-400 hover:text-slate-200 hover:border-indigo-500/30 transition-all shrink-0"
                  style={{ fontFamily: HE }}
                >
                  <Code2 className="w-3.5 h-3.5" />
                  {showCode ? "הסתר קוד" : "צפה בקוד"}
                  {showCode ? (
                    <ChevronUp className="w-3 h-3" />
                  ) : (
                    <ChevronDown className="w-3 h-3" />
                  )}
                </button>
              )}
            </div>

            {/* Collapsible code view */}
            <AnimatePresence>
              {showCode && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden mt-2"
                >
                  <div className="relative rounded-xl border border-white/[0.08] bg-[#0a0a0f] overflow-hidden">
                    {/* Code header */}
                    <div className="flex items-center justify-between px-4 py-2 border-b border-white/[0.06] bg-[#111118]">
                      <span className="text-[11px] text-slate-500 font-mono">
                        {codeLang === "html" || codeLang === null ? "index.html"
                          : codeLang === "jsx" || codeLang === "tsx" ? `App.${codeLang}`
                          : codeLang === "css" ? "style.css"
                          : codeLang === "js" || codeLang === "ts" ? `index.${codeLang}`
                          : `output.${codeLang}`}
                      </span>
                      <button
                        onClick={handleCopy}
                        className="flex items-center gap-1.5 text-[11px] text-slate-400 hover:text-slate-200 transition-colors"
                        style={{ fontFamily: HE }}
                      >
                        {copied ? (
                          <>
                            <Check className="w-3 h-3 text-emerald-400" />
                            <span className="text-emerald-400">הועתק!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3 h-3" />
                            העתק
                          </>
                        )}
                      </button>
                    </div>
                    {/* Code content */}
                    <pre
                      className="p-4 text-[11px] text-slate-300 font-mono leading-relaxed overflow-x-auto max-h-80 overflow-y-auto scrollbar-thin scrollbar-thumb-white/[0.08]"
                      dir="ltr"
                    >
                      <code>{extractedCode}</code>
                    </pre>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}
      </div>
    </motion.div>
  );
}
