import { GitCommitHorizontal, Plus, Minus, FileCode2, Layers } from "lucide-react";
import { cn } from "@/lib/utils";

const HE = "'Rubik', sans-serif";

export interface ChangeSummary {
  generationType: "first" | "full" | "patch";
  linesAdded: number;
  linesRemoved: number;
  changePercent: number;
  sectionsChanged: string[];
  filesChanged?: string[];
}

interface TrustCardProps {
  summary: ChangeSummary;
}

const TYPE_CONFIG = {
  first: {
    label: "יצירה ראשונה",
    icon: "✨",
    color: "border-indigo-500/25 bg-indigo-500/5",
    badge: "bg-indigo-500/20 text-indigo-300",
  },
  full: {
    label: "בנייה מחדש",
    icon: "⚡",
    color: "border-blue-500/25 bg-blue-500/5",
    badge: "bg-blue-500/20 text-blue-300",
  },
  patch: {
    label: "עדכון מינימלי",
    icon: "🔧",
    color: "border-emerald-500/25 bg-emerald-500/5",
    badge: "bg-emerald-500/20 text-emerald-300",
  },
};

export function TrustCard({ summary }: TrustCardProps) {
  const cfg = TYPE_CONFIG[summary.generationType];
  const hasChanges = summary.linesAdded > 0 || summary.linesRemoved > 0;

  return (
    <div
      className={cn(
        "rounded-xl border px-3 py-2.5 text-xs space-y-2",
        cfg.color,
      )}
      style={{ fontFamily: HE }}
      dir="rtl"
    >
      {/* Header row */}
      <div className="flex items-center gap-2">
        <GitCommitHorizontal className="w-3.5 h-3.5 text-muted-foreground/60 shrink-0" />
        <span className="text-muted-foreground/70 font-medium">שינויים בקוד</span>
        <span
          className={cn(
            "mr-auto px-2 py-0.5 rounded-full text-[10px] font-semibold",
            cfg.badge,
          )}
        >
          {cfg.icon} {cfg.label}
        </span>
      </div>

      {/* Stats row */}
      {hasChanges && summary.generationType !== "first" && (
        <div className="flex items-center gap-3 text-[11px]">
          {summary.linesAdded > 0 && (
            <span className="flex items-center gap-1 text-emerald-400">
              <Plus className="w-3 h-3" />
              {summary.linesAdded} שורות
            </span>
          )}
          {summary.linesRemoved > 0 && (
            <span className="flex items-center gap-1 text-red-400">
              <Minus className="w-3 h-3" />
              {summary.linesRemoved} שורות
            </span>
          )}
          {summary.changePercent > 0 && (
            <span className="text-muted-foreground/50 mr-auto">
              {summary.changePercent}% שונה
            </span>
          )}
        </div>
      )}

      {/* Sections changed */}
      {summary.sectionsChanged.length > 0 && (
        <div className="flex items-start gap-1.5">
          <Layers className="w-3 h-3 text-muted-foreground/40 mt-0.5 shrink-0" />
          <div className="flex flex-wrap gap-1">
            {summary.sectionsChanged.map((s, i) => {
              const isAdded = s.startsWith("+ ");
              const isRemoved = s.startsWith("- ");
              const label = s.replace(/^[+\-] /, "");
              return (
                <span
                  key={i}
                  className={cn(
                    "px-1.5 py-0.5 rounded text-[10px] border",
                    isAdded
                      ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                      : isRemoved
                        ? "bg-red-500/10 text-red-400 border-red-500/20"
                        : "bg-white/5 text-muted-foreground/60 border-white/10",
                  )}
                >
                  {isAdded ? "+" : isRemoved ? "−" : ""} {label}
                </span>
              );
            })}
          </div>
        </div>
      )}

      {/* Files changed (React projects) */}
      {summary.filesChanged && summary.filesChanged.length > 0 && (
        <div className="flex items-start gap-1.5">
          <FileCode2 className="w-3 h-3 text-muted-foreground/40 mt-0.5 shrink-0" />
          <div className="flex flex-wrap gap-1">
            {summary.filesChanged.map((f, i) => (
              <span
                key={i}
                className="px-1.5 py-0.5 rounded text-[10px] bg-violet-500/10 text-violet-400 border border-violet-500/20 font-mono"
                dir="ltr"
              >
                {f}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
