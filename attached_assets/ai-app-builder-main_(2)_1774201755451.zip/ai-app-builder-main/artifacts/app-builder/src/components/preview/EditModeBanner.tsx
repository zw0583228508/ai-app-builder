import { MousePointerClick, X as XIcon } from "lucide-react";

const HE = "'Rubik', sans-serif";

interface SelectedElement {
  tag: string;
  selector: string;
}

interface EditModeBannerProps {
  selectedEl: SelectedElement | null;
  onClose: () => void;
}

export function EditModeBanner({ selectedEl, onClose }: EditModeBannerProps) {
  return (
    <div
      className="shrink-0 bg-primary/10 border-b border-primary/20 px-4 py-2 flex items-center justify-between"
      dir="rtl"
    >
      <div className="flex items-center gap-2">
        <MousePointerClick className="w-4 h-4 text-primary" />
        <span
          className="text-xs text-primary font-medium"
          style={{ fontFamily: HE }}
        >
          {selectedEl
            ? `נבחר: <${selectedEl.tag}>${selectedEl.selector !== selectedEl.tag ? ` ${selectedEl.selector}` : ""}`
            : "לחץ על אלמנט כדי לבחור ולערוך אותו עם AI"}
        </span>
      </div>
      <button
        onClick={onClose}
        className="text-muted-foreground hover:text-foreground"
      >
        <XIcon className="w-3.5 h-3.5" />
      </button>
    </div>
  );
}
