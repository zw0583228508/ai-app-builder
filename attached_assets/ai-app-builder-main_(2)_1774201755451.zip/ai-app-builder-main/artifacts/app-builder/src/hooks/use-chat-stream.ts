import { useState, useCallback, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { getGetProjectQueryKey } from "@workspace/api-client-react";
import { readIntegrations } from "./use-integrations";
import type { ChangeSummary } from "@/components/TrustCard";

export interface Attachment {
  name: string;
  type: string;
  data: string;
  size: number;
  preview?: string;
}

export interface PipelineStep {
  step: "architecture" | "ui" | "security" | "performance";
  done: boolean;
}

export interface AgentStepUI {
  id: number;
  emoji: string;
  title: string;
  status: "pending" | "running" | "done";
}

export interface AgentFixEntry {
  iteration: number;
  fixed: boolean;
  issues: string[];
}

export type AgentPhase = "planning" | "executing" | "fixing" | null;

export interface ChatSuggestion {
  type: string;
  title: string;
  desc: string;
  action: string;
}

export interface DetectedChatIntent {
  intent: string;
  label: string;
  emoji: string;
}

interface UseChatStreamOptions {
  projectId: number;
  onPreviewUpdated?: () => void;
  onModeDetected?: (mode: string) => void;
  onGrowWithMe?: (suggestedMode: string) => void;
  onError?: (err: Error) => void;
  onActionResult?: (action: string, data: Record<string, unknown>) => void;
}

export function useChatStream({
  projectId,
  onPreviewUpdated,
  onModeDetected,
  onGrowWithMe,
  onError,
  onActionResult,
}: UseChatStreamOptions) {
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamedText, setStreamedText] = useState("");
  const [isGeneratingCode, setIsGeneratingCode] = useState(false);
  const [codeLines, setCodeLines] = useState(0);
  const [skillScore, setSkillScore] = useState<number | null>(null);
  const [pipelineMessage, setPipelineMessage] = useState<string | null>(null);
  const [entrepreneurPlan, setEntrepreneurPlan] = useState<Record<string, unknown> | null>(null);
  const [pipelineSteps, setPipelineSteps] = useState<PipelineStep[]>([]);

  // ── Agent flow state ──────────────────────────────────────────────────────
  const [agentPhase, setAgentPhase] = useState<AgentPhase>(null);
  const [agentSteps, setAgentSteps] = useState<AgentStepUI[]>([]);
  const [agentFixLog, setAgentFixLog] = useState<AgentFixEntry[]>([]);
  const [agentStepsCompleted, setAgentStepsCompleted] = useState<number | null>(null);

  // ── Intent & Suggestions state ────────────────────────────────────────────
  const [currentIntent, setCurrentIntent] = useState<DetectedChatIntent | null>(null);
  const [suggestions, setSuggestions] = useState<ChatSuggestion[]>([]);
  const [lastChangeSummary, setLastChangeSummary] = useState<ChangeSummary | null>(null);
  const [streamError, setStreamError] = useState<string | null>(null);

  const queryClient = useQueryClient();
  const abortControllerRef = useRef<AbortController | null>(null);
  const liveHtmlRef = useRef("");

  // Typewriter animation
  const typewriterQueueRef = useRef("");
  const typewriterShownRef  = useRef("");
  const typewriterTimerRef  = useRef<ReturnType<typeof setInterval> | null>(null);
  const networkDoneRef      = useRef(false);

  const stopTypewriter = useCallback(() => {
    if (typewriterTimerRef.current) {
      clearInterval(typewriterTimerRef.current);
      typewriterTimerRef.current = null;
    }
  }, []);

  const lastChunkTimeRef = useRef<number>(0);
  const avgChunkIntervalRef = useRef<number>(1200);

  const startTypewriter = useCallback(() => {
    if (typewriterTimerRef.current) return;
    typewriterTimerRef.current = setInterval(() => {
      const queue = typewriterQueueRef.current;
      if (queue.length === 0) {
        if (networkDoneRef.current) stopTypewriter();
        return;
      }
      const TICK_MS = 30;
      const targetCharsPerSec = Math.max(
        40,
        queue.length > 500 ? 400 :
        queue.length > 150 ? 120 :
        Math.round((queue.length / avgChunkIntervalRef.current) * 1000 * 0.5)
      );
      const charsPerTick = Math.max(1, Math.round(targetCharsPerSec * TICK_MS / 1000));
      const slice = queue.slice(0, charsPerTick);
      typewriterQueueRef.current = queue.slice(charsPerTick);
      typewriterShownRef.current += slice;
      setStreamedText(typewriterShownRef.current);
    }, 30);
  }, [stopTypewriter]);

  const appendStreamedText = useCallback((chunk: string) => {
    const now = Date.now();
    if (lastChunkTimeRef.current > 0) {
      const delta = now - lastChunkTimeRef.current;
      avgChunkIntervalRef.current = 0.3 * delta + 0.7 * avgChunkIntervalRef.current;
    }
    lastChunkTimeRef.current = now;
    typewriterQueueRef.current += chunk;
    startTypewriter();
  }, [startTypewriter]);

  const flushTypewriter = useCallback(() => {
    stopTypewriter();
    if (typewriterQueueRef.current) {
      typewriterShownRef.current += typewriterQueueRef.current;
      typewriterQueueRef.current = "";
      setStreamedText(typewriterShownRef.current);
    }
  }, [stopTypewriter]);

  const isGeneratingCodeRef = useRef(false);

  const sendMessage = useCallback(
    async (content: string, attachments?: Attachment[], agentFlow?: boolean) => {
      setIsStreaming(true);
      setStreamedText("");
      setIsGeneratingCode(false);
      setCodeLines(0);
      setLastChangeSummary(null);
      liveHtmlRef.current = "";
      // Reset typewriter state
      stopTypewriter();
      typewriterQueueRef.current = "";
      typewriterShownRef.current = "";
      networkDoneRef.current = false;
      lastChunkTimeRef.current = 0;
      avgChunkIntervalRef.current = 1200;
      // Reset agent state
      setAgentPhase(null);
      setAgentSteps([]);
      setAgentFixLog([]);
      setAgentStepsCompleted(null);
      // Reset intent, suggestions, and any previous error
      setCurrentIntent(null);
      setSuggestions([]);
      setStreamError(null);

      abortControllerRef.current = new AbortController();

      try {
        const creds = readIntegrations();
        const integrations: Record<string, string> = {};
        const CRED_KEYS: (keyof typeof creds)[] = [
          "supabaseUrl", "supabaseAnonKey",
          "openaiKey", "anthropicKey", "groqKey", "huggingfaceToken", "replicateToken",
          "firebaseApiKey", "firebaseProjectId",
          "mongodbUri", "planetscaleUrl",
          "upstashRedisUrl", "upstashRedisToken",
          "stripePublishableKey", "stripeSecretKey",
          "paypalClientId",
          "auth0Domain", "auth0ClientId",
          "clerkPublishableKey",
          "cloudinaryCloudName", "cloudinaryApiKey", "cloudinaryApiSecret",
          "twilioAccountSid", "twilioAuthToken",
          "sendgridApiKey", "resendApiKey",
          "pusherKey", "pusherSecret", "pusherAppId", "pusherCluster",
          "googleMapsApiKey", "mapboxToken",
          "algoliaAppId", "algoliaApiKey",
          "slackBotToken", "discordBotToken", "twitterBearerToken",
          "githubToken", "vercelToken", "railwayToken", "renderApiKey",
        ];
        CRED_KEYS.forEach(k => { if (creds[k]) integrations[k] = creds[k] as string; });

        const body: Record<string, unknown> = { content };
        if (Object.keys(integrations).length > 0) body.integrations = integrations;
        if (attachments && attachments.length > 0) {
          body.attachments = attachments.map(a => ({
            name: a.name,
            type: a.type,
            data: a.data,
            size: a.size,
          }));
        }
        if (agentFlow) body.agentFlow = true;

        const res = await fetch(`/api/projects/${projectId}/messages`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
          signal: abortControllerRef.current.signal,
        });

        if (!res.ok) {
          const errData = await res.json().catch(() => ({}));
          throw new Error(errData.error || "Failed to send message");
        }

        const reader = res.body?.getReader();
        if (!reader) throw new Error("No response body stream");

        const decoder = new TextDecoder();
        let buffer = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() || "";

          for (const line of lines) {
            const trimmedLine = line.trim();
            if (!trimmedLine.startsWith("data: ")) continue;

            try {
              const dataStr = trimmedLine.slice(6);
              if (!dataStr) continue;
              const data = JSON.parse(dataStr);

              // ── Pipeline events (standard flow) ───────────────────────────
              if (data.type === "pipeline_start") {
                setPipelineMessage(data.message ?? "מנתח בקשה...");
                setPipelineSteps([]);
              } else if (data.type === "pipeline_step") {
                setPipelineSteps(prev => {
                  const already = prev.find(s => s.step === data.step);
                  if (already) return prev;
                  return [...prev, { step: data.step, done: true }];
                });
              } else if (data.type === "pipeline_done") {
                setPipelineMessage(null);

              // ── Agent flow events ──────────────────────────────────────────
              } else if (data.type === "agent_phase") {
                setAgentPhase(data.phase ?? "planning");
                if (data.message) setPipelineMessage(data.message);

              } else if (data.type === "agent_plan" && Array.isArray(data.steps)) {
                setAgentPhase("executing");
                setPipelineMessage(null);
                setAgentSteps(
                  (data.steps as Array<{ id: number; emoji: string; title: string }>).map(s => ({
                    id: s.id,
                    emoji: s.emoji,
                    title: s.title,
                    status: "pending" as const,
                  }))
                );

              } else if (data.type === "agent_step_start" && data.stepId != null) {
                setAgentPhase("executing");
                setAgentSteps(prev =>
                  prev.map(s => s.id === data.stepId ? { ...s, status: "running" as const } : s)
                );

              } else if (data.type === "agent_step_done" && data.stepId != null) {
                setAgentSteps(prev =>
                  prev.map(s => s.id === data.stepId ? { ...s, status: "done" as const } : s)
                );

              } else if (data.type === "agent_fix_start") {
                setAgentPhase("fixing");

              } else if (data.type === "agent_fix_done") {
                setAgentFixLog(prev => [
                  ...prev,
                  {
                    iteration: data.iteration ?? 1,
                    fixed: Boolean(data.fixed),
                    issues: Array.isArray(data.issues) ? data.issues : [],
                  },
                ]);

              // ── Entrepreneur planning phase (Issue 14) ─────────────────────
              } else if (data.type === "entrepreneur_plan" && data.plan) {
                setEntrepreneurPlan(data.plan as Record<string, unknown>);

              // ── Intent detection ───────────────────────────────────────────
              } else if (data.type === "intent_detected") {
                setCurrentIntent({ intent: data.intent, label: data.label, emoji: data.emoji });

              // ── Contextual suggestions ─────────────────────────────────────
              } else if (data.type === "suggestions" && Array.isArray(data.suggestions)) {
                setSuggestions(data.suggestions as ChatSuggestion[]);

              // ── Done event ─────────────────────────────────────────────────
              } else if (data.done) {
                setPipelineMessage(null);
                setPipelineSteps([]);
                setIsGeneratingCode(false);
                if (data.agentDone) {
                  setAgentPhase(null);
                  if (data.stepsCompleted != null) setAgentStepsCompleted(data.stepsCompleted);
                }
                if (data.previewUpdated) {
                  window.dispatchEvent(
                    new CustomEvent("builder-preview-updated", { detail: { projectId } })
                  );
                  onPreviewUpdated?.();
                }
                if (data.filesUpdated) {
                  window.dispatchEvent(
                    new CustomEvent("builder-files-updated", { detail: { projectId } })
                  );
                }
                if (data.detectedMode) onModeDetected?.(data.detectedMode);
                if (data.skillScore !== undefined) setSkillScore(data.skillScore);
                if (data.growWithMeSuggestion) onGrowWithMe?.(data.growWithMeSuggestion);
                if (data.action) onActionResult?.(data.action as string, data as Record<string, unknown>);
                if (data.changeSummary) setLastChangeSummary(data.changeSummary as ChangeSummary);

              // ── Streaming content ──────────────────────────────────────────
              } else if (data.content !== undefined) {
                const chunk: string = data.content;
                const isCode = data.type === "code";

                if (isCode) {
                  if (!isGeneratingCodeRef.current) {
                    isGeneratingCodeRef.current = true;
                    setIsGeneratingCode(true);
                  }
                  liveHtmlRef.current += chunk;
                  const lines = liveHtmlRef.current.split("\n").length;
                  setCodeLines(lines);

                  window.dispatchEvent(
                    new CustomEvent("builder-preview-streaming", {
                      detail: { projectId, html: liveHtmlRef.current },
                    })
                  );
                } else {
                  if (isGeneratingCodeRef.current) {
                    isGeneratingCodeRef.current = false;
                    setIsGeneratingCode(false);
                  }
                  appendStreamedText(chunk);
                }
              }
            } catch (e) {
              console.warn("Failed to parse SSE chunk:", trimmedLine, e);
            }
          }
        }
      } catch (err) {
        if ((err as Error).name !== "AbortError") {
          console.error("[useChatStream] Error:", err);
          onError?.(err as Error);
          const msg = (err as Error).message || "";
          if (msg.toLowerCase().includes("rate limit") || msg.toLowerCase().includes("429")) {
            setStreamError("הגעת למגבלת ההודעות היומית. נסה שוב מחר.");
          } else if (msg.toLowerCase().includes("unauthorized") || msg.toLowerCase().includes("401")) {
            setStreamError("אין הרשאה. אנא התחבר מחדש.");
          } else {
            setStreamError("שגיאה בשליחת ההודעה. אנא נסה שוב.");
          }
        }
      } finally {
        networkDoneRef.current = true;
        flushTypewriter();
        setIsStreaming(false);
        setIsGeneratingCode(false);
        setCodeLines(0);
        setPipelineMessage(null);
        setPipelineSteps([]);
        liveHtmlRef.current = "";
        abortControllerRef.current = null;
        queryClient.invalidateQueries({ queryKey: getGetProjectQueryKey(projectId) });
        // Always fire so PreviewPanel can clear its streaming state
        window.dispatchEvent(new CustomEvent("builder-build-ended", { detail: { projectId } }));
      }
    },
    [projectId, queryClient, onPreviewUpdated, onModeDetected, onGrowWithMe, onError, appendStreamedText, stopTypewriter, flushTypewriter]
  );

  const stopStreaming = useCallback(() => {
    abortControllerRef.current?.abort();
  }, []);

  return {
    sendMessage,
    isStreaming,
    streamedText,
    isGeneratingCode,
    codeLines,
    stopStreaming,
    skillScore,
    streamedContent: streamedText,
    pipelineMessage,
    pipelineSteps,
    // Agent flow
    agentPhase,
    agentSteps,
    agentFixLog,
    agentStepsCompleted,
    // Intent & suggestions
    currentIntent,
    suggestions,
    clearSuggestions: () => setSuggestions([]),
    // Entrepreneur planning phase (Issue 14)
    entrepreneurPlan,
    clearEntrepreneurPlan: () => setEntrepreneurPlan(null),
    // Trust layer
    lastChangeSummary,
    clearChangeSummary: () => setLastChangeSummary(null),
    // Stream error (shown when stream fails)
    streamError,
    clearStreamError: () => setStreamError(null),
  };
}
