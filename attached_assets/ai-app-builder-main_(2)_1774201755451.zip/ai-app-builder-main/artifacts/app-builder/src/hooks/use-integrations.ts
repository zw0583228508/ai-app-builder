import { useState, useCallback, useEffect, useRef } from "react";

export interface Integrations {
  // Deployment & Source Control
  githubToken: string;
  vercelToken: string;
  netlifyToken: string;
  railwayToken: string;
  renderApiKey: string;
  // Databases & Backend
  supabaseUrl: string;
  supabaseAnonKey: string;
  firebaseApiKey: string;
  firebaseProjectId: string;
  mongodbUri: string;
  planetscaleUrl: string;
  upstashRedisUrl: string;
  upstashRedisToken: string;
  // AI & LLM
  openaiKey: string;
  anthropicKey: string;
  groqKey: string;
  huggingfaceToken: string;
  replicateToken: string;
  // Auth
  auth0Domain: string;
  auth0ClientId: string;
  clerkPublishableKey: string;
  // Payments
  stripePublishableKey: string;
  stripeSecretKey: string;
  paypalClientId: string;
  // Storage & Media
  cloudinaryCloudName: string;
  cloudinaryApiKey: string;
  cloudinaryApiSecret: string;
  // Communication
  twilioAccountSid: string;
  twilioAuthToken: string;
  sendgridApiKey: string;
  resendApiKey: string;
  pusherAppId: string;
  pusherKey: string;
  pusherSecret: string;
  pusherCluster: string;
  // Maps & Search
  googleMapsApiKey: string;
  mapboxToken: string;
  algoliaAppId: string;
  algoliaApiKey: string;
  // Social & Messaging
  slackBotToken: string;
  discordBotToken: string;
  twitterBearerToken: string;
}

const DEFAULT_INTEGRATIONS: Integrations = {
  githubToken: "",
  vercelToken: "",
  netlifyToken: "",
  railwayToken: "",
  renderApiKey: "",
  supabaseUrl: "",
  supabaseAnonKey: "",
  firebaseApiKey: "",
  firebaseProjectId: "",
  mongodbUri: "",
  planetscaleUrl: "",
  upstashRedisUrl: "",
  upstashRedisToken: "",
  openaiKey: "",
  anthropicKey: "",
  groqKey: "",
  huggingfaceToken: "",
  replicateToken: "",
  auth0Domain: "",
  auth0ClientId: "",
  clerkPublishableKey: "",
  stripePublishableKey: "",
  stripeSecretKey: "",
  paypalClientId: "",
  cloudinaryCloudName: "",
  cloudinaryApiKey: "",
  cloudinaryApiSecret: "",
  twilioAccountSid: "",
  twilioAuthToken: "",
  sendgridApiKey: "",
  resendApiKey: "",
  pusherAppId: "",
  pusherKey: "",
  pusherSecret: "",
  pusherCluster: "",
  googleMapsApiKey: "",
  mapboxToken: "",
  algoliaAppId: "",
  algoliaApiKey: "",
  slackBotToken: "",
  discordBotToken: "",
  twitterBearerToken: "",
};

const API_BASE = import.meta.env.BASE_URL?.replace(/\/$/, "") ?? "";

// Module-level cache so readIntegrations() works synchronously in callbacks
let _cachedIntegrations: Integrations = { ...DEFAULT_INTEGRATIONS };

/** Synchronous read from in-memory cache — safe to call outside React hooks */
export function readIntegrations(): Integrations {
  return _cachedIntegrations;
}

async function fetchServerIntegrations(): Promise<Integrations> {
  try {
    const res = await fetch(`${API_BASE}/api/user/integrations`, {
      credentials: "include",
    });
    if (!res.ok) return DEFAULT_INTEGRATIONS;
    const data = (await res.json()) as { integrations: Record<string, string> };
    return {
      ...DEFAULT_INTEGRATIONS,
      ...(data.integrations ?? {}),
    } as Integrations;
  } catch {
    return DEFAULT_INTEGRATIONS;
  }
}

async function saveServerIntegrations(
  integrations: Integrations,
): Promise<void> {
  try {
    await fetch(`${API_BASE}/api/user/integrations`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      credentials: "include",
      body: JSON.stringify(integrations),
    });
  } catch {
    // silently ignore — server sync is best-effort
  }
}

export function useIntegrations() {
  const [integrations, setIntegrations] =
    useState<Integrations>(DEFAULT_INTEGRATIONS);
  const [loaded, setLoaded] = useState(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Load from server on mount
  useEffect(() => {
    fetchServerIntegrations().then((data) => {
      _cachedIntegrations = data;
      setIntegrations(data);
      setLoaded(true);
    });
  }, []);

  const setField = useCallback((field: keyof Integrations, value: string) => {
    setIntegrations((prev) => {
      const next = { ...prev, [field]: value };
      _cachedIntegrations = next;
      // Debounced save to server — 800ms after last keystroke
      if (saveTimer.current) clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(() => saveServerIntegrations(next), 800);
      return next;
    });
  }, []);

  const clearField = useCallback(
    (field: keyof Integrations) => {
      setField(field, "");
    },
    [setField],
  );

  const getActiveIntegrations = useCallback(() => {
    const active: Record<string, boolean> = {};
    if (integrations.githubToken) active.github = true;
    if (integrations.supabaseUrl && integrations.supabaseAnonKey)
      active.supabase = true;
    if (integrations.vercelToken) active.vercel = true;
    if (integrations.openaiKey) active.openai = true;
    if (integrations.netlifyToken) active.netlify = true;
    if (integrations.firebaseApiKey) active.firebase = true;
    if (integrations.mongodbUri) active.mongodb = true;
    if (integrations.anthropicKey) active.anthropic = true;
    if (integrations.groqKey) active.groq = true;
    if (integrations.stripePublishableKey) active.stripe = true;
    if (integrations.auth0Domain) active.auth0 = true;
    if (integrations.clerkPublishableKey) active.clerk = true;
    if (integrations.twilioAccountSid) active.twilio = true;
    if (integrations.sendgridApiKey) active.sendgrid = true;
    if (integrations.resendApiKey) active.resend = true;
    if (integrations.cloudinaryCloudName) active.cloudinary = true;
    if (integrations.pusherKey) active.pusher = true;
    if (integrations.googleMapsApiKey) active.googlemaps = true;
    if (integrations.mapboxToken) active.mapbox = true;
    if (integrations.algoliaAppId) active.algolia = true;
    if (integrations.slackBotToken) active.slack = true;
    return active;
  }, [integrations]);

  return { integrations, setField, clearField, getActiveIntegrations, loaded };
}
