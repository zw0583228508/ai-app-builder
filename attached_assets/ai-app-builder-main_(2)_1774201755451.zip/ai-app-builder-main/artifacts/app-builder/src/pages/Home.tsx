import { useState, useRef, useEffect } from "react";
import { Layout } from "@/components/Layout";
import {
  ArrowUp, LayoutTemplate, Clock, FileCode2, Zap,
  Globe, ShoppingBag, Briefcase, BarChart3, BookOpen,
  Palette, Rocket, Brain, Shield, DollarSign, Activity,
  ListTodo, Cpu, Mic, GitFork, Webhook, Bug, Gauge,
  MessageCircle, Image, Code2, Database, HardDrive,
  Wand2, ChevronRight, Lock, CreditCard, Settings,
  Sparkles, Play, Layers
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { TemplatesModal } from "@/components/TemplatesModal";
import { useLocation } from "wouter";
import { useListProjects } from "@workspace/api-client-react";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { useLang } from "@/lib/i18n";

const PRIMARY = "hsl(191,90%,42%)";

export default function Home() {
  const { t, meta, lang } = useLang();
  const isRTL = meta.rtl;

  const [showTemplates, setShowTemplates] = useState(false);
  const [input, setInput] = useState("");
  const [isCreating, setIsCreating] = useState(false);
  const [selectedMode, setSelectedMode] = useState("entrepreneur");
  const [, navigate] = useLocation();
  const { data: projects, isLoading: projectsLoading } = useListProjects();
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = "auto";
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 240) + "px";
    }
  }, [input]);

  const QUICK_TEMPLATES = [
    { icon: ShoppingBag,  label: t("tplStore"),     prompt: "Build a beautiful e-commerce store with product gallery, cart, checkout and order tracking." },
    { icon: Globe,        label: t("tplLanding"),   prompt: "Build a stunning SaaS landing page with hero, features, pricing and a strong CTA." },
    { icon: Briefcase,    label: t("tplBusiness"),  prompt: "Build a professional business website with about, services, reviews and contact." },
    { icon: BarChart3,    label: t("tplDashboard"), prompt: "Build an analytics dashboard with charts, KPIs and interactive data tables." },
    { icon: BookOpen,     label: t("tplBlog"),      prompt: "Build a designer/developer portfolio with gallery, bio and contact form." },
    { icon: Palette,      label: t("tplCreative"),  prompt: "Build a creative website with animations, gallery and unique design." },
    { icon: Rocket,       label: t("tplSaaS"),      prompt: "Build a full SaaS app with Auth, Dashboard, Admin Panel and Billing." },
    { icon: Database,     label: t("tplDB"),        prompt: "Build an app with database, forms, CRUD and modern design." },
  ];

  const USER_MODES = [
    { id: "entrepreneur", icon: "🏢", label: t("modeEntrepreneur"), color: "border-cyan-500/60 bg-cyan-500/10 text-cyan-300" },
    { id: "builder",      icon: "🔧", label: t("modeBuilder"),      color: "border-orange-500/60 bg-orange-500/10 text-orange-300" },
    { id: "developer",    icon: "💻", label: t("modeDeveloper"),    color: "border-green-500/60 bg-green-500/10 text-green-300" },
    { id: "maker",        icon: "🎨", label: t("modeMaker"),        color: "border-purple-500/60 bg-purple-500/10 text-purple-300" },
  ];

  const handleCreate = async (prompt?: string, mode?: string) => {
    const text = prompt ?? input.trim();
    if (!text || isCreating) return;
    setIsCreating(true);
    try {
      const title = text.slice(0, 50) + (text.length > 50 ? "..." : "");
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, type: "website", userMode: mode ?? selectedMode }),
      });
      if (!res.ok) throw new Error();
      const project = await res.json();
      sessionStorage.setItem("builder_pending_prompt", text);
      navigate(`/project/${project.id}`);
    } catch {
      setIsCreating(false);
    }
  };

  const handleSelectTemplate = async (prompt: string, title: string) => {
    setIsCreating(true);
    try {
      const res = await fetch("/api/projects", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, type: "website", userMode: selectedMode }),
      });
      if (!res.ok) throw new Error();
      const project = await res.json();
      sessionStorage.setItem("builder_pending_prompt", prompt);
      navigate(`/project/${project.id}`);
    } catch {
      setIsCreating(false);
    }
  };

  const recentProjects = projects?.slice(0, 6) ?? [];

  return (
    <Layout>
      <div
        className="relative w-full h-full overflow-y-auto"
        dir={isRTL ? "rtl" : "ltr"}
        style={{ fontFamily: meta.font, background: "hsl(220,16%,5%)" }}
        key={lang}
      >
        {/* Ambient glow */}
        <div className="pointer-events-none fixed inset-0 z-0 overflow-hidden">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[900px] h-[500px] bg-[hsl(191,90%,42%)]/5 rounded-full blur-[120px]" />
          <div className="absolute top-1/4 left-1/4 w-[400px] h-[400px] bg-purple-600/4 rounded-full blur-[100px]" />
        </div>

        <div className="relative z-10 flex flex-col items-center min-h-full px-4 pt-12 pb-20">

          {/* ── Logo + tagline ── */}
          <motion.div
            initial={{ opacity: 0, y: -12 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center mb-10"
          >
            <div className="flex items-center gap-2.5 mb-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-[hsl(191,90%,42%)] to-purple-500 flex items-center justify-center shadow-lg shadow-[hsl(191,90%,42%)]/30">
                <Sparkles className="w-5 h-5 text-white" />
              </div>
              <span className="text-2xl font-black text-white tracking-tight">AI Builder</span>
            </div>
            <p className="text-sm text-white/40 max-w-sm text-center leading-relaxed">
              {t("heroSubtitle")}
            </p>
          </motion.div>

          {/* ── Mode pills ── */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.06 }}
            className="flex items-center gap-2 mb-4 flex-wrap justify-center"
          >
            {USER_MODES.map(m => (
              <button
                key={m.id}
                onClick={() => setSelectedMode(m.id)}
                className={cn(
                  "flex items-center gap-1.5 px-3 py-1.5 rounded-full border text-xs font-medium transition-all",
                  selectedMode === m.id
                    ? m.color
                    : "border-white/10 bg-white/4 text-white/40 hover:text-white/70 hover:border-white/20"
                )}
              >
                <span>{m.icon}</span>
                {m.label}
              </button>
            ))}
          </motion.div>

          {/* ── Main prompt input ── */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="w-full max-w-2xl mb-4"
          >
            <div className="relative rounded-2xl border border-white/10 bg-white/[0.04] shadow-2xl shadow-black/50 focus-within:border-[hsl(191,90%,42%)]/50 focus-within:shadow-[hsl(191,90%,42%)]/10 focus-within:shadow-2xl transition-all duration-300">
              <textarea
                ref={textareaRef}
                value={input}
                onChange={e => setInput(e.target.value)}
                onKeyDown={e => {
                  if (e.key === "Enter" && !e.shiftKey && input.trim()) {
                    e.preventDefault();
                    handleCreate();
                  }
                }}
                placeholder={t("inputPlaceholder")}
                className="w-full bg-transparent px-5 pt-5 pb-3 text-[15px] text-white placeholder:text-white/25 resize-none focus:outline-none min-h-[100px] leading-relaxed"
                dir={isRTL ? "rtl" : "ltr"}
                rows={3}
              />

              {/* Bottom toolbar */}
              <div className={cn("flex items-center justify-between px-4 pb-4 pt-1 gap-3", isRTL && "flex-row-reverse")}>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setShowTemplates(true)}
                    className="flex items-center gap-1.5 text-xs text-white/35 hover:text-white/70 transition-colors"
                  >
                    <LayoutTemplate className="w-3.5 h-3.5" />
                    {t("readyTemplates")}
                  </button>
                  <button
                    onClick={() => navigate("/gallery")}
                    className="flex items-center gap-1.5 text-xs text-white/35 hover:text-white/70 transition-colors"
                  >
                    <Layers className="w-3.5 h-3.5" />
                    {t("communityGallery")}
                  </button>
                </div>
                <button
                  onClick={() => handleCreate()}
                  disabled={!input.trim() || isCreating}
                  className="flex items-center gap-2 px-5 py-2.5 bg-[hsl(191,90%,42%)] text-black rounded-xl text-sm font-bold disabled:opacity-40 hover:bg-[hsl(191,90%,50%)] transition-all shadow-lg shadow-[hsl(191,90%,42%)]/30 hover:-translate-y-0.5 disabled:hover:translate-y-0 active:translate-y-0 shrink-0"
                >
                  {isCreating
                    ? <span className="w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin" />
                    : <ArrowUp className="w-4 h-4" />
                  }
                  {isCreating ? t("buildingBtn") : t("buildBtn")}
                </button>
              </div>
            </div>
          </motion.div>

          {/* ── Template chips ── */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.15 }}
            className="flex flex-wrap justify-center gap-2 mb-12 max-w-2xl"
          >
            {QUICK_TEMPLATES.map(tp => (
              <button
                key={tp.label}
                onClick={() => handleCreate(tp.prompt)}
                disabled={isCreating}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-white/[0.04] border border-white/[0.07] rounded-full text-xs text-white/40 hover:text-white/80 hover:border-[hsl(191,90%,42%)]/30 hover:bg-[hsl(191,90%,42%)]/5 transition-all"
              >
                <tp.icon className="w-3 h-3 text-[hsl(191,90%,42%)]/50" />
                {tp.label}
              </button>
            ))}
            <button
              onClick={() => setShowTemplates(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-white/[0.04] border border-dashed border-white/[0.07] rounded-full text-xs text-white/30 hover:text-[hsl(191,90%,42%)] hover:border-[hsl(191,90%,42%)]/30 transition-all"
            >
              <Zap className="w-3 h-3" />
              {t("moreTemplates")}
            </button>
          </motion.div>

          {/* ── Recent projects (with skeleton loaders) ── */}
          {(projectsLoading || recentProjects.length > 0) && (
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="w-full max-w-2xl mb-12"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-white/25" />
                  <span className="text-xs text-white/25 font-medium uppercase tracking-wider">{t("recentProjects")}</span>
                </div>
                <button
                  onClick={() => navigate("/gallery")}
                  className="flex items-center gap-1 text-xs text-white/25 hover:text-white/50 transition-colors"
                >
                  {t("gallery")} <ChevronRight className="w-3 h-3" />
                </button>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {projectsLoading
                  ? Array.from({ length: 4 }).map((_, i) => (
                      <div
                        key={i}
                        className="flex items-center gap-3 px-4 py-3 bg-white/[0.02] border border-white/[0.05] rounded-xl animate-pulse"
                      >
                        <div className="w-8 h-8 rounded-lg bg-white/[0.04] shrink-0" />
                        <div className="flex-1 min-w-0 space-y-1.5">
                          <div className="h-3 bg-white/[0.06] rounded w-3/4" />
                          <div className="h-2.5 bg-white/[0.04] rounded w-1/3" />
                        </div>
                      </div>
                    ))
                  : recentProjects.map((p, i) => (
                      <motion.button
                        key={p.id}
                        initial={{ opacity: 0, y: 6 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{ delay: 0.22 + i * 0.03 }}
                        onClick={() => navigate(`/project/${p.id}`)}
                        className={cn(
                          "flex items-center gap-3 px-4 py-3 bg-white/[0.03] border border-white/[0.06] rounded-xl hover:border-white/12 hover:bg-white/[0.05] transition-all group",
                          isRTL ? "text-right" : "text-left"
                        )}
                      >
                        <div className="w-8 h-8 rounded-lg bg-[hsl(191,90%,42%)]/8 border border-[hsl(191,90%,42%)]/15 flex items-center justify-center shrink-0">
                          <FileCode2 className="w-3.5 h-3.5 text-[hsl(191,90%,42%)]/50 group-hover:text-[hsl(191,90%,42%)] transition-colors" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-[13px] font-medium text-white/65 group-hover:text-white/90 truncate transition-colors">{p.title}</p>
                          <p className="text-[11px] text-white/25" dir="ltr">{format(new Date(p.updatedAt), "d MMM, HH:mm")}</p>
                        </div>
                        <ChevronRight className="w-3.5 h-3.5 text-white/15 group-hover:text-white/40 transition-all group-hover:translate-x-0.5 shrink-0" />
                      </motion.button>
                    ))}
              </div>
            </motion.div>
          )}

          {/* ── Feature grid (bottom) ── */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="w-full max-w-2xl"
          >
            <div className="flex items-center gap-3 mb-4">
              <div className="flex-1 h-px bg-white/[0.06]" />
              <span className="text-[10px] text-white/20 uppercase tracking-[0.2em] font-medium shrink-0">
                {t("featuresTitle")}
              </span>
              <div className="flex-1 h-px bg-white/[0.06]" />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { icon: Brain,    label: t("featPlannerAgent"), color: "text-cyan-400",   bg: "bg-cyan-500/8 border-cyan-500/15" },
                { icon: Shield,   label: t("featQA"),           color: "text-green-400",  bg: "bg-green-500/8 border-green-500/15" },
                { icon: Rocket,   label: t("featSaaS"),         color: "text-purple-400", bg: "bg-purple-500/8 border-purple-500/15" },
                { icon: Globe,    label: t("featDeploy"),       color: "text-blue-400",   bg: "bg-blue-500/8 border-blue-500/15" },
                { icon: Activity, label: t("featRuntime"),      color: "text-orange-400", bg: "bg-orange-500/8 border-orange-500/15" },
                { icon: Code2,    label: t("featMonaco"),       color: "text-white/60",   bg: "bg-white/4 border-white/8" },
                { icon: Image,    label: t("featImageGen"),     color: "text-yellow-400", bg: "bg-yellow-500/8 border-yellow-500/15" },
                { icon: Mic,      label: t("featVoice"),        color: "text-pink-400",   bg: "bg-pink-500/8 border-pink-500/15" },
              ].map((f, i) => (
                <div
                  key={i}
                  className={cn("flex items-center gap-2 px-3 py-2.5 rounded-xl border", f.bg)}
                >
                  <f.icon className={cn("w-3.5 h-3.5 shrink-0", f.color)} />
                  <span className="text-[11px] text-white/50 truncate">{f.label}</span>
                </div>
              ))}
            </div>

            {/* SaaS CTA */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="mt-4 rounded-2xl border border-[hsl(191,90%,42%)]/20 bg-gradient-to-r from-[hsl(191,90%,42%)]/8 to-purple-500/5 px-5 py-4 flex items-center justify-between gap-4"
            >
              <div>
                <p className="text-sm font-bold text-white" style={{ fontFamily: meta.font }}>{t("saasTitle1")} {t("saasTitle2")}</p>
                <p className="text-xs text-white/40 mt-0.5">{t("saasSubtitle")}</p>
              </div>
              <button
                onClick={() => handleCreate("Build a full SaaS app with auth, dashboard, admin panel, stripe billing and analytics")}
                className="flex items-center gap-2 px-4 py-2 bg-[hsl(191,90%,42%)] text-black rounded-lg text-xs font-bold hover:bg-[hsl(191,90%,50%)] transition-all shrink-0 shadow-md shadow-[hsl(191,90%,42%)]/20"
              >
                <Play className="w-3.5 h-3.5" />
                {t("tryNow")}
              </button>
            </motion.div>
          </motion.div>

        </div>

        <TemplatesModal
          isOpen={showTemplates}
          onClose={() => setShowTemplates(false)}
          onSelectTemplate={handleSelectTemplate}
        />
      </div>
    </Layout>
  );
}
