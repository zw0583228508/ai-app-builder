import { useAuth } from "@workspace/replit-auth-web";
import { Sparkles, Wand2, Zap, Globe, Shield, ArrowLeft } from "lucide-react";
import { motion } from "framer-motion";

const HE = "'Rubik', sans-serif";

const FEATURES = [
  { icon: Wand2, label: "בנה כל אפליקציה", desc: "רק תכתוב מה אתה רוצה — ה-AI יבנה בשבילך" },
  { icon: Zap, label: "תצוגה חיה", desc: "ראה את האפליקציה שלך מתעדכנת בזמן אמת" },
  { icon: Globe, label: "פרסם בלחיצה", desc: "העלה לאינטרנט ושתף עם כולם בשנייה" },
  { icon: Shield, label: "הכל שמור", desc: "היסטוריית גרסאות מלאה ושחזור בקלות" },
];

export default function Login() {
  const { login, isLoading } = useAuth();

  return (
    <div
      className="min-h-screen w-full flex flex-col items-center justify-center bg-background relative overflow-hidden"
      style={{ fontFamily: HE }}
      dir="rtl"
    >
      {/* Background glow */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 right-1/4 w-[600px] h-[600px] bg-cyan-500/5 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 left-1/4 w-[400px] h-[400px] bg-violet-500/5 rounded-full blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 flex flex-col items-center gap-8 max-w-md w-full px-6"
      >
        {/* Logo */}
        <div className="flex flex-col items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-cyan-500 to-violet-600 flex items-center justify-center shadow-2xl shadow-cyan-500/25">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <div className="text-center">
            <h1 className="text-3xl font-bold text-foreground tracking-tight">בונה AI</h1>
            <p className="text-muted-foreground text-sm mt-1">הפלטפורמה לבניית אפליקציות עם AI</p>
          </div>
        </div>

        {/* Features */}
        <div className="grid grid-cols-2 gap-3 w-full">
          {FEATURES.map((f, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 + i * 0.05 }}
              className="bg-card/50 border border-border/40 rounded-2xl p-4 flex flex-col gap-2"
            >
              <div className="w-8 h-8 rounded-xl bg-primary/10 flex items-center justify-center">
                <f.icon className="w-4 h-4 text-primary" />
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">{f.label}</p>
                <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{f.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Login button */}
        <div className="w-full flex flex-col gap-3">
          <button
            onClick={login}
            disabled={isLoading}
            className="w-full h-12 bg-gradient-to-r from-cyan-500 to-violet-600 text-white font-semibold rounded-2xl flex items-center justify-center gap-2 hover:opacity-90 hover:-translate-y-0.5 transition-all shadow-lg shadow-cyan-500/25 disabled:opacity-50"
          >
            <ArrowLeft className="w-4 h-4" />
            {isLoading ? "טוען..." : "התחבר ובנה עכשיו"}
          </button>
          <p className="text-center text-xs text-muted-foreground">
            חינם לגמרי · ללא כרטיס אשראי
          </p>
        </div>
      </motion.div>
    </div>
  );
}
