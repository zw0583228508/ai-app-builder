import { useEffect, useState } from "react";
import { useRoute } from "wouter";
import { Loader2, AlertCircle, ExternalLink } from "lucide-react";

const HE = "'Rubik', sans-serif";

export default function ShareView() {
  const [, params] = useRoute("/s/:token");
  const token = params?.token;
  const [status, setStatus] = useState<"loading" | "ok" | "error">("loading");

  useEffect(() => {
    if (token) setStatus("ok");
    else setStatus("error");
  }, [token]);

  if (!token) {
    return (
      <div className="flex flex-col items-center justify-center h-screen bg-background text-center" dir="rtl">
        <AlertCircle className="w-12 h-12 text-destructive mb-4" />
        <h1 className="text-xl font-bold" style={{ fontFamily: HE }}>קישור לא תקין</h1>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-screen bg-background">
      {/* Minimal header */}
      <div className="h-10 border-b border-border/40 bg-black/80 flex items-center justify-between px-4 shrink-0" dir="rtl">
        <div className="flex items-center gap-2">
          <div className="w-5 h-5 rounded bg-primary/20 flex items-center justify-center">
            <span className="text-[10px] text-primary font-bold">B</span>
          </div>
          <span className="text-xs text-muted-foreground" style={{ fontFamily: HE }}>
            נבנה עם Builder AI
          </span>
        </div>
        <a
          href="/"
          className="flex items-center gap-1 text-xs text-primary hover:underline"
          style={{ fontFamily: HE }}
        >
          <ExternalLink className="w-3 h-3" />
          צור פרויקט משלך
        </a>
      </div>

      {/* Full-screen preview iframe */}
      {status === "loading" && (
        <div className="flex-1 flex items-center justify-center">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
        </div>
      )}

      <iframe
        src={`/api/projects/share/${token}`}
        className="flex-1 w-full border-none"
        title="Shared Project"
        onLoad={() => setStatus("ok")}
        onError={() => setStatus("error")}
        sandbox="allow-scripts allow-forms allow-popups allow-modals"
      />

      {status === "error" && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-background text-center" dir="rtl">
          <AlertCircle className="w-12 h-12 text-destructive mb-4" />
          <h1 className="text-xl font-bold" style={{ fontFamily: HE }}>הפרויקט לא נמצא</h1>
          <p className="text-muted-foreground text-sm mt-2" style={{ fontFamily: HE }}>
            הקישור לא תקין או שהפרויקט נמחק.
          </p>
        </div>
      )}
    </div>
  );
}
